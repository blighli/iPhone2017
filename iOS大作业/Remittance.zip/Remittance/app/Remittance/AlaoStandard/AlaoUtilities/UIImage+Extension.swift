//
//  UIImage+Extension.swift
//  ShareLibrary-swift
//
//  Created by wansy on 15/12/22.
//  Copyright © 2015年 com.hengtiansoft. All rights reserved.
//

import UIKit

extension UIImage{
    
    /**
     根据颜色生成一张图片
     
     - parameter color: 颜色
     
     - returns: 生成的图片
     */
    class func image(color:UIColor) -> UIImage?
    {
        let imageW:CGFloat = 100
        let imageH:CGFloat = 100
        UIGraphicsBeginImageContextWithOptions(CGSize(width: imageW, height:imageH), false, 0.0)
        
        color.set()
        UIRectFill(CGRect(x:0, y:0, width:imageW, height:imageH))
        let image = UIGraphicsGetImageFromCurrentImageContext()
        
        UIGraphicsEndImageContext()
        return image
    }

}
