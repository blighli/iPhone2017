//
//  String+Validity.swift
//  Remittance
//
//  Created by wansy on 2017/7/6.
//  Copyright © 2017年 wansy. All rights reserved.
//

import UIKit

extension String {
    /**
     验证字符串是不是手机号码
    
     - returns: 是／否
     */
    func isValidateMobile() -> Bool{
        
        let regex = "^1([38]\\d{2}|4[57]\\d{1}|5[0-35-9]\\d{1}|70[059])\\d{7}$"
        let pred = NSPredicate(format:"SELF MATCHES %@", regex)
        return pred.evaluate(with: self)
        
    }
    
    //判断是否是小写字母
    func isPureLowletters() -> Bool{
        
        let regex = "[a-z]*"
        let pred = NSPredicate(format:"SELF MATCHES %@", regex)
        return pred.evaluate(with: self)
        
    }
}
