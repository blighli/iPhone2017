//
//  String+Extension.swift
//  wuliangye
//
//  Created by wansy on 16/5/24.
//  Copyright © 2016年 wansy. All rights reserved.
//

import Foundation

extension String {
    /**
     MD5加密
     
     - returns: 加密后的字符串
     */
    func md5() ->String!{
        
        let str = self.cString(using: .utf8)
        let strLen = CC_LONG(self.lengthOfBytes(using: .utf8))
        let digestLen = Int(CC_MD5_DIGEST_LENGTH)
        let result = UnsafeMutablePointer<CUnsignedChar>.allocate(capacity: digestLen)
        
        CC_MD5(str!, strLen, result)
        
        let hash = NSMutableString()
        for i in 0..<digestLen {
            hash.appendFormat("%02x", result[i])
        }
        
        result.deallocate(capacity: digestLen)
        
        return String(format: hash as String)
    }
    
}
