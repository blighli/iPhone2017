//
//  UINavigationController+ShouldPopOnBackButton.swift
//  Remittance
//
//  Created by wansy on 2017/9/29.
//  Copyright © 2017年 wansy. All rights reserved.
//

import Foundation

extension UINavigationController{
    
    func navigationBar(navigationBar: UINavigationBar, shouldPopItem item:UINavigationItem) -> Bool{
        if self.viewControllers.count < (navigationBar.items?.count)! {
            return true
        }
        
        var shouldPop = true
        let vc = self.topViewController
        if vc != nil && (vc?.responds(to: #selector(BackButtonHandlerProtocol.navigationShouldPopOnBackButton)))! {
            shouldPop = vc!.navigationShouldPopOnBackButton()
        }
        
        if shouldPop {
            DispatchQueue.main.async {
                self.popViewController(animated: true)
            }
        }else {
            for subView in navigationBar.subviews {
                if subView.alpha < 1 {
                    UIView.animate(withDuration: 0.25,animations: {
                        subView.alpha = 1.0
                    })
                }
            }
        }
        return false
    }
    
}
