//
//  UIViewController+Extension.swift
//  ShareLibrary-swift
//
//  Created by wansy on 15/12/22.
//  Copyright © 2015年 com.hengtiansoft. All rights reserved.
//

import UIKit

extension UIViewController{
    
    //MARK:  - UI
    //  展示提醒view
    
    func showTips(tips:String) -> Void {
        DispatchQueue.main.async() {
            SVProgressHUD.showInfo(withStatus: tips)
            self.perform(#selector(UIViewController.hideHUD), with: nil, afterDelay: 1.5)
        }
    }
    
    func showSuccessTips(tips:String) -> Void {
        DispatchQueue.main.async() {
            SVProgressHUD.showSuccess(withStatus: tips)
            self.perform(#selector(UIViewController.hideHUD), with: nil, afterDelay: 1.5)
        }
    }
    
    func showErrorTips(tips:String) -> Void {
        DispatchQueue.main.async() {
            SVProgressHUD.showError(withStatus: tips)
            self.perform(#selector(UIViewController.hideHUD), with: nil, afterDelay: 1.5)
        }
    }
    
    func showHUDWithTitle(tips:String) -> Void {
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
        DispatchQueue.main.async() {
            SVProgressHUD.show(withStatus: tips)
        }
    }
    
    func showHUDAndDisableUserInteractionWithTitle(tips:String) -> Void {
        DispatchQueue.main.async() {
            SVProgressHUD.setDefaultMaskType(.gradient)
            SVProgressHUD.showInfo(withStatus: tips)
            self.perform(#selector(UIViewController.hideHUD), with: nil, afterDelay: 1.5)
        }
    }
    
    func hideHUD() {
        UIApplication.shared.isNetworkActivityIndicatorVisible = false
        DispatchQueue.main.async() {
            SVProgressHUD.setDefaultMaskType(.none)
            SVProgressHUD.dismiss()
        }
    }
    
    //MARK: - present
    
    /**
     跳转到storyboard中的viewController
     
     - parameter storyboardName: storyboardName
     - parameter vcIdentifier:   控制器id
     */
    func presentViewController(storyboardName:String,vcIdentifier:String) {
        let viewController = self.viewControllerInStoryboard(storyboardName: storyboardName, vcIdentifier: vcIdentifier)
        self.present(viewController, animated: true, completion: nil)
    }
    
    /**
     获取storyboard中的viewController
     
     - parameter storyboardName: storyboardName
     - parameter vcIdentifier:   控制器id
     
     - returns: 制定的viewcontroller
     */
    func viewControllerInStoryboard(storyboardName:String,vcIdentifier:String) -> UIViewController{
        let storyboard = UIStoryboard(name: storyboardName,bundle:nil)
        return  storyboard.instantiateViewController(withIdentifier: vcIdentifier)
    }
    
    //MARK:  - Notification
    
    /**
     添加通知
     
     - parameter notificationNames: 通知名称
     */
    func addObserverForNotifications(notificationNames:[String]) -> Void {
        for name in notificationNames {
            NotificationCenter.default.addObserver(self, selector: #selector(BaseViewController.didReceivedNotification(notification:)), name: NSNotification.Name(rawValue: name), object: nil)
        }
    }
    
    /**
     移除通知
     
     - parameter notificationNames: 通知名称
     */
    func removeObserverForNotifications(notificationNames:[String]) -> Void {
        for name in notificationNames {
            NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: name), object: nil)
        }
    }

}
