//
//  ss.swift
//  wuliangye
//
//  Created by wansy on 16/6/12.
//  Copyright © 2016年 wansy. All rights reserved.
//

import Foundation
import UIKit

extension UIWebView {
    /**
     调整webview中图片的大小
     
     - parameter imageWidth: 改变后的宽度
     */
    func adjustWebViewImageSize(imageWidth:CGFloat){
        self.allowsInlineMediaPlayback = true
        self.stringByEvaluatingJavaScript(from: "var script = document.createElement('script');script.type = 'text/javascript';script.text = \"function ResizeImages() { var myimg,oldwidth;var maxwidth = \(UIScreen.main.bounds.width);for(i=0;i <document.images.length;i++){myimg = document.images[i];oldwidth = myimg.width;myimg.width = maxwidth; }}\";document.getElementsByTagName('head')[0].appendChild(script);")
        
        self.stringByEvaluatingJavaScript(from: "ResizeImages();")
        
    }
}
