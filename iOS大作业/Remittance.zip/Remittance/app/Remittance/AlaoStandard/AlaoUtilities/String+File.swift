////
////  String+Extension.swift
////  WaterDetection-Swift
////
////  Created by wansy on 15/9/2.
////  Copyright (c) 2015年 com.hengtiansoft. All rights reserved.
////
//
//import Foundation
//import UIKit
//
//extension String{
//    
//     /**
//     快速返回沙盒中，Documents文件的路径
//     
//     - returns: Documents文件的路径
//     */
//    static func pathForDocuments() -> String
//    {
//        return NSSearchPathForDirectoriesInDomains(NSSearchPathDirectory.DocumentDirectory,NSSearchPathDomainMask.UserDomainMask,true).last as String!
//    }
//    
//     /**
//     快速返回Documents文件中某个子文件的路径
//     
//     - parameter fileName: fileName 子文件名称
//     
//     - returns: 快速返回Documents文件中某个子文件的路径
//     */
//    static func filePathAtDocumentsWithFileName(fileName:String) -> String
//    {
//        return FileManager().URLForDirectory(.DocumentDirectory, inDomain: .UserDomainMask, appropriateForURL: nil, create: true).URLByAppendingPathComponent(fileName).path!
//    }
//    
//     /**
//     快速返回沙盒中Library下Caches文件的路径
//     
//     - returns: 快速返回沙盒中Library下Caches文件的路径
//     */
//    static func pathForCaches() -> String
//    {
//        return NSSearchPathForDirectoriesInDomains(NSSearchPathDirectory.CachesDirectory, NSSearchPathDomainMask.UserDomainMask, true).last as String!
//    }
//    
//    static func filePathAtCachesWithFileName(fileName:String) -> String
//    {
//        return try!  NSFileManager().URLForDirectory(.CachesDirectory, inDomain: .UserDomainMask, appropriateForURL: nil, create: true).URLByAppendingPathComponent(fileName).path!
//    }
//    
//     /**
//     快速返回MainBundle(资源捆绑包的)的路径
//     
//     - returns: 快速返回MainBundle(资源捆绑包的)的路径
//     */
//    static func pathForMainBundle() -> String {
//        return Bundle.main.bundlePath
//    }
//    
////    func filePathAtMainBundleWithFileName(fileName:String) -> String
////    {
////        return pathForMainBundle().stringByAppendingPathComponent(fileName)
////    }
//    
//    /**
//    快速返回沙盒中tmp(临时文件)文件的路径
//    
//    - returns: 快速返回沙盒中tmp文件的路径
//    */
//    static func pathForTemp() -> String {
//        return NSTemporaryDirectory()
//    }
//
////    func filePathAtTempWithFileName(fileName:String) -> String
////    {
////        return pathForTemp().stringByAppendingPathComponent(fileName)
////    }
//    
//    /**
//    快速返回沙盒中，Library下Preferences文件的路径
//    
//    - returns: 快速返回沙盒中Library下Caches文件的路径
//    */
//    static func pathForPreferences() -> String {
//        return NSSearchPathForDirectoriesInDomains(NSSearchPathDirectory.PreferencePanesDirectory,  NSSearchPathDomainMask.UserDomainMask, true).last as String!
//    }
//    
////    func filePathAtPreferencesWithFileName(fileName:String) -> String
////    {
////        return pathForPreferences().stringByAppendingPathComponent(fileName)
////    }
//
//    /**
//    快速你指定的系统文件的路径
//    
//    - parameter directory: NSSearchPathDirectory枚举
//    
//    - returns: 快速你指定的系统文件的路径
//    */
//    static func pathForSystemFile(directory:NSSearchPathDirectory) -> String {
//        return NSSearchPathForDirectoriesInDomains(directory,  NSSearchPathDomainMask.UserDomainMask, true).last as String!
//    }
//
////    func filePathForSystemFile(directory:NSSearchPathDirectory,fileName:String) -> String
////    {
////        return pathForSystemFile(directory).stringByAppendingPathComponent(fileName)
////    }
//}
