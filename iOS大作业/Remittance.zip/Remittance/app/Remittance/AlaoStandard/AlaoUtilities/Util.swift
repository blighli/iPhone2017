//
//  Util.swift
//  ShareLibrary-swift
//
//  Created by wansy on 15/12/22.
//  Copyright © 2015年 com.hengtiansoft. All rights reserved.
//

import Foundation
import UIKit

struct DateFormater {
    static let YMD    = "yyyy-MM-dd"
    static let YMDHMS = "yyyy-MM-dd HH:mm:ss"
    static let HM     = "HH:mm"
    static let HMS    = "HH:mm:ss"
}

class Util: NSObject {
    /**
     将string转化成指定格式的date
     
     - parameter string:    要转换的string
     - parameter formatter: 转化的格式 (默认格式为"yyyy-MM-dd HH:mm:ss")
     
     - returns: 转换好的date
     */
    class func dateFromString(string:String,formatter:String = DateFormater.YMDHMS) ->NSDate
    {
        let dateFormatter = DateFormatter()
        dateFormatter.timeZone = NSTimeZone(abbreviation: "GMT")! as TimeZone
        dateFormatter.dateFormat = formatter
        return dateFormatter.date(from: string)! as NSDate
    }
    
    /**
     将date转化成指定格式的string
     
     - parameter date:      要转化的date
     - parameter formatter: 转化的格式 (默认格式为"yyyy-MM-dd HH:mm:ss")
     
     - returns: 转化好的string
     */
    class func stringFormDate(date:NSDate,formatter:String = DateFormater.YMDHMS) ->String
    {
        let dateFormatter = DateFormatter()
        dateFormatter.timeZone = NSTimeZone(abbreviation: "GMT")! as TimeZone
        dateFormatter.dateFormat = formatter
        
        let zone = NSTimeZone.system
        let interval = zone.secondsFromGMT(for: date as Date)
        
        let localDate = date.addingTimeInterval(TimeInterval(interval))
        
        return dateFormatter.string(from: localDate as Date)
    }
    
    /// 获取当前时间的时间戳
    ///
    /// - Returns: 时间戳
    class func getNowTimeInterval() -> String{
        let date = NSDate(timeIntervalSinceNow: 0)
        let interval = date.timeIntervalSince1970 * 1000
        
        return NSString(format:"%.0f", interval) as String
    }
    
    /// 获取时间字符串的时间戳
    ///
    /// - Parameter dateStr: 时间字符串
    /// - Returns: 时间戳
    class func getTimeIntervalWithStr(_ dateStr: String) -> String{
        let date = Util.dateFromString(string: dateStr, formatter: DateFormater.YMDHMS)
        let interval = date.timeIntervalSince1970 * 1000
        
        return NSString(format:"%.0f", interval) as String
    }

    /// 时间戳转化成时间字符串
    ///
    /// - Parameters:
    ///   - interval: 时间戳
    ///   - formatter: 格式
    /// - Returns: 时间字符串
    class func getDateStr(withTimeInterval interval:Double, formatter:String = DateFormater.YMDHMS) -> String{
        let date = NSDate.init(timeIntervalSince1970: interval / 1000)
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = formatter
        return dateFormatter.string(from: date as Date)
    }
}
