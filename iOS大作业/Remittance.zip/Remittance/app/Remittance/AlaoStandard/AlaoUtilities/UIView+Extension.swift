//
//  UIView+Extension.swift
//  ShareLibrary-swift
//
//  Created by wansy on 15/12/22.
//  Copyright © 2015年 com.hengtiansoft. All rights reserved.
//

import Foundation
import UIKit

extension UIView{
    
    /**
     将UIView画圆(一般宽高相同)
     */
    func markCricle() ->Void
    {
        self.layer.cornerRadius = self.frame.size.height * 0.5
        self.layer.masksToBounds = true
    }
    
    /**
     画圆角
     
     - parameter radius: 圆角半径
     */
    func makeRoundedCorner(radius:CGFloat) ->Void
    {
        self.layer.cornerRadius = radius
        self.layer.masksToBounds = true
    }
    
    /**
     将UIView画圆并加上边框(一般宽高相同)
     
     - parameter borderColor: 边框颜色
     - parameter borderWidth: 边框宽度
     */
    func makeCircle(borderColor:UIColor,borderWidth:CGFloat) ->Void
    {
        self.layer.borderWidth = borderWidth
        self.layer.borderColor = borderColor.cgColor
        self.markCricle()
    }
    
    /**
     画圆角并加上边框
     
     - parameter radius:      圆角半径
     - parameter borderColor: 边框颜色
     - parameter borderWidth: 边框宽度
     */
    func makeRoundedCorner(radius:CGFloat,borderColor:UIColor,borderWidth:CGFloat) ->Void
    {
        self.layer.borderWidth = borderWidth
        self.layer.borderColor = borderColor.cgColor
        self.makeRoundedCorner(radius: radius)
    }
    
    
    /// 自定义圆角
    ///
    /// - Parameters:
    ///   - corner: 具体哪个圆角
    ///   - cornerRadii: 圆角尺寸
    func customCorner(byRoundingCorners corner:UIRectCorner,cornerRadii:CGSize)
    {
        let maskPath = UIBezierPath(roundedRect:self.bounds, byRoundingCorners: corner, cornerRadii: cornerRadii)
        let maskLayer = CAShapeLayer()
        maskLayer.frame = self.bounds
        maskLayer.path = maskPath.cgPath
        self.layer.mask = maskLayer
    }
}
