//
//  Color.swift
//  Remittance
//
//  Created by wansy on 2017/9/21.
//  Copyright © 2017年 wansy. All rights reserved.
//

struct Color {
    static let ThemeColor = Color().color(hex: 0x142541)
    static let ThemeColor2 = Color().color(hex: 0x47566E)
    static let ThemeColor3 = UIColor(red: 20.0/255.0, green: 37.0/255.0, blue: 65.0/255.0, alpha: 1)
    
    func color(hex:u_long,alpha:CGFloat = 1.0) -> UIColor{
        let red = ((CGFloat)((hex & 0xFF0000) >> 16)) / 255.0
        let green = ((CGFloat)((hex & 0xFF00) >> 8))/255.0
        let blue = ((CGFloat)(hex & 0xFF))/255.0
        
        return UIColor(red: red,green: green,blue: blue,alpha: alpha)
    }
}
