////
////  FileManager.swift
////  ShareLibrary-swift
////
////  Created by wansy on 15/12/28.
////  Copyright © 2015年 com.hengtiansoft. All rights reserved.
////
//
//import UIKit
//
//class AlaoFileManager: NSObject {
//    
//    class func writeToFile(fileName name:String,data:NSData)
//    {
//        let filePath:String = String.filePathAtDocumentsWithFileName(fileName: name)
//        
//        print(filePath)
//    }
//}
