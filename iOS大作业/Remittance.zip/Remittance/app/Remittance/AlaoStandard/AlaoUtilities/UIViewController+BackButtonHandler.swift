//
//  BackButtonHandler.swift
//  Remittance
//
//  Created by wansy on 2017/9/29.
//  Copyright © 2017年 wansy. All rights reserved.
//

import Foundation

@objc
protocol BackButtonHandlerProtocol {
    
@objc optional
    func navigationShouldPopOnBackButton() -> Bool
    
}

extension UIViewController: BackButtonHandlerProtocol{
    
}
