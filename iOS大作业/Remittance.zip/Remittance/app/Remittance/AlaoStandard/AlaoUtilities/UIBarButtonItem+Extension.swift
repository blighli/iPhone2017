//
//  UIBarButtonItem+Extension.swift
//  cln
//
//  Created by wansy on 2017/5/19.
//  Copyright © 2017年 wansy. All rights reserved.
//

import Foundation
import UIKit

extension UIBarButtonItem{
    
    /// 自定义UIBarButtonItem
    ///
    /// - Parameters:
    ///   - image: 正常图片
    ///   - image2: 高亮图片
    ///   - target: 控制器
    ///   - action: 行为
    ///   - size: 按钮尺寸
    /// - Returns: 返回自定义的button
    class func barButtonItem(withImage image:UIImage,
                             highlightedImage image2:UIImage,
                             target:AnyObject,
                             action:Selector,
                             size:CGSize) ->UIBarButtonItem
    {
        
        let button = UIButton()
        button.setImage(image, for: .normal)
        button.setImage(image2, for: .highlighted)
        button.bounds = CGRect(x: 0, y: 0, width: size.width, height: size.height)
        
        button.addTarget(target, action: action, for: .touchUpInside)
        return UIBarButtonItem.init(customView: button)
    }
}
