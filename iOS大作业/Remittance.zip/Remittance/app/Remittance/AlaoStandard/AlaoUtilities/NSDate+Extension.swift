//
//  NSCalendar+Extension.swift
//  ShareLibrary-swift
//
//  Created by wansy on 15/12/21.
//  Copyright © 2015年 com.hengtiansoft. All rights reserved.
//

import Foundation

extension NSDate {
    
    private class func calendar() ->NSCalendar!
    {
        var cal = NSCalendar.current
        cal.timeZone = NSTimeZone(abbreviation: "GMT")! as TimeZone
        return cal as NSCalendar;
    }
    
    private func components() -> NSDateComponents!
    {
        return NSDate.calendar().components([NSCalendar.Unit.month,NSCalendar.Unit.year, NSCalendar.Unit.day,NSCalendar.Unit.weekday], from: self as Date) as NSDateComponents
    }
    
    /**
     比较两个日期的年月日是不是相同
     
     - parameter date: 被比较的时间
     
     - returns: ture(是)/false(否)
     */
    func isYMDEqualToDate(date:NSDate!) -> Bool
    {
        let c1 = self.components()
        let c2 = date.components()
        
        return (c1!.year == c2!.year && c1!.month == c2!.month && c1!.day == c2!.day);
    }
    
    /**
     判断是不是今天
     
     - returns: ture(是)/false(否)
     */
    func isToday() -> Bool
    {
       return self.isYMDEqualToDate(date: NSDate())
    }
    
    /**
     根据日期返回几号
     
     - returns: day
     */
    func day() -> Int
    {
        let components:NSDateComponents = NSDate.calendar().components(NSCalendar.Unit.day, from: self as Date) as NSDateComponents
        return components.day
    }
    
    /**
     根据日期返回星期几
     
     - returns: weekDay
     */
    func weekDay() -> Int
    {
        let components:NSDateComponents = NSDate.calendar().components(NSCalendar.Unit.weekday, from: self as Date) as NSDateComponents
        return components.weekday - 1
    }
    
    /**
     根据日期返回月份
     
     - returns: month
     */
    func month() -> Int
    {
        let components:NSDateComponents = NSDate.calendar().components(NSCalendar.Unit.month, from: self as Date) as NSDateComponents
        return components.month
    }
    
    /**
     根据日期返回年份
     
     - returns: year
     */
    func year() -> Int
    {
        let components:NSDateComponents = NSDate.calendar().components(NSCalendar.Unit.year, from: self as Date) as NSDateComponents
        return components.year
    }
    
    /**
     获取标准时间（yyyy-MM-dd 00:00:00）
     
     - returns: 标准时间
     */
    func standardizationDate() ->NSDate
    {
        let dateStr = Util.stringFormDate(date: self,formatter: DateFormater.YMD)
        return Util.dateFromString(string: dateStr)
    }
}
