//
//  Result.swift
//  AlamofireObjectMapperDemo
//
//  Created by wansy on 16/4/18.
//  Copyright © 2016年 wansy. All rights reserved.
//

import ObjectMapper

/* 请求响应实体*/
struct ResponseEntity {
    static let code    = "code" //响应状态码
    static let data    = "data" //响应数据
    static let message = "msg"  //响应消息
}

/* 请求响应状态码*/
enum ResponseCode:Int{
    case success      = 0  //请求成功
    case failure      = 1  //请求失败
    case tokenExpired = 2  //token过期
    case other        = 99 //其他
    
    static func fromRawValue(value:Int?) -> ResponseCode {
        guard let value = value else {
            return .other
        }

        switch value {
        case 0:
            return .success
        case 1:
            return .failure
        case 2:
            return .tokenExpired
        default:
            return .other
        }
    }
    
    func description() -> String {
        switch self {
        case .success:
            return "请求成功"
        case .failure:
            return "请求失败"
        case .tokenExpired:
            return "Token过期"
        default:
            return "其他问题"
        }
    }
}

/* 非数组返回类型*/
class ResultEntity<T:Mappable>: Mappable {
    var code:Int?
    var data:T?
    var message:String?

    required init?(map: Map) {
        
    }
    
    func mapping(map: Map) {
        code <- map[ResponseEntity.code]
        data <- map[ResponseEntity.data]
        message <- map[ResponseEntity.message]
    }
}

/* 数组返回类型*/
class ResultArray<T:Mappable>: Mappable {
    var code:Int?
    var data:[T]?
    var message:String?
    
    required init?(map: Map) {
        
    }
    
    func mapping(map: Map) {
        code <- map[ResponseEntity.code]
        data <- map[ResponseEntity.data]
        message <- map[ResponseEntity.message]
    }
}
