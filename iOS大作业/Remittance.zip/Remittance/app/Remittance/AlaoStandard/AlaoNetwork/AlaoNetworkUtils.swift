
//
//  NetworkConfig.swift
//  cln
//
//  Created by wansy on 2017/5/10.
//  Copyright © 2017年 wansy. All rights reserved.
//

import Foundation

private struct configKey {
    static let config = "AlaoNetworkConfig"  /* 配置文件名 */
    static let plist  = "plist"              /* 配置文件类型 */

    static let baseServerSchema        = "Base Server Schema"        /* 服务器Schema键值 */
    static let baseServerAddressDev    = "Base Server Address Dev"   /* 开发环境键值 */
    static let baseServerAddressTest   = "Base Server Address Test"  /* 测试环境键值 */
    static let baseServerAddressDis    = "Base Server Address Dis"   /* 生产环境键值 */
    static let timeoutInterval         = "Timeout Interval"          /* 网络访问时限键值 */
}

enum ServerAddressType {
    case development   /* 开发环境 */
    case test          /* 测试环境 */
    case distribution  /* 生产环境 */
}

class AlaoNetworkUtils {
    
    //MARK: - 私有方法
    
    /// 读取plist文件中指定key的value
    ///
    /// - Parameter key: key
    /// - Returns: value
    private static func readConfigObject(forKey key:String) -> String{
        let path = Bundle.main.path(forResource: configKey.config, ofType: configKey.plist)
        let dic = NSMutableDictionary(contentsOfFile:path!)
        
        if let resStr = dic?.object(forKey: key) {
            return resStr as! String
        }else {
            return "0"
        }
    }
    
    //MARK: - 公有方法
    
    /// 获取Schma
    ///
    /// - Returns: Schma
    static func baseServerSchema() -> String{
        return self.readConfigObject(forKey: configKey.baseServerSchema)
    }
    
    /// 根据开发环境获取baseUrl路径
    ///
    /// - Parameter type: 开发环境类型
    /// - Returns: baseUrl
    static func baseServerAddress(forType type:ServerAddressType) -> String{
        var baseServerAddress = ""
        switch type {
        case .development:
            baseServerAddress = self.readConfigObject(forKey: configKey.baseServerAddressDev)
        case .test:
            baseServerAddress = self.readConfigObject(forKey: configKey.baseServerAddressTest)
        case .distribution:
            baseServerAddress = self.readConfigObject(forKey: configKey.baseServerAddressDis)
        }
        return baseServerAddress;
    }
    
    /// 拼接完整的baseUrl路径
    ///
    /// - Returns: 完整baseUrl路径
    static func baseServerPath() -> String{
        let type = ServerAddressType.development
    
        let baseServerSchema = self.baseServerSchema()
        let baseServerAddress = self.baseServerAddress(forType: type)
        let baseServerPath = String(format:"%@%@",baseServerSchema,baseServerAddress)
        
        return baseServerPath;
    }
    
    /// 拼接完整Url路径
    ///
    /// - Parameter path: 子路径
    /// - Returns: 完整路径
    static func createUrl(subPath path:String) ->URL? {
        let urlStr = String(format:"%@%@",self.baseServerPath(),path)
        return URL(string:urlStr)
    }
    
    /// 获取http请求超时时间
    ///
    /// - Returns: 时间
    static func timeoutInterval() -> TimeInterval {
        let timeoutInterval = self.readConfigObject(forKey: configKey.timeoutInterval)
        var resTime:Double = 0
        
        if let doubleValue = Double(timeoutInterval){
            resTime = doubleValue
        }
        return resTime
    }
}
