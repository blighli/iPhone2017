//
//  URLConstant.swift
//  AlamofireObjectMapperDemo
//
//  Created by wansy on 17/5/10.
//  Copyright © 2016年 wansy. All rights reserved.
//



struct AlaoURLConstant {
    
    struct Remit {
        static let START_REMIT_MONEY    = "/cross-border/startRemitMoney"   // 开始一笔汇款
        static let CHANGEOVER           = "/cross-border/changeOver"        // 转接
        static let RECORDED             = "/cross-border/recorded"          // 记录
        static let CLEARING             = "/cross-border/clearing"          // 清算
        static let GET_ORDER            = "/cross-border/getOrder"          // 获取汇款详情
        static let TRANSACTION_INFO     = "/cross-border/getTotalTx"        // 交易数据
        static let BILL_NUM             = "/cross-border/billNum"        // 交易数据
        static let BILL_LIST            = "/cross-border/billList"          // 汇款列表
        static let TRANSACTION_AMOUNT   = "/cross-border/transactionAmount" // 一周交易量
    }
    
}
