//
//  WebService.swift
//  AlamofireObjectMapperDemo
//
//  Created by wansy on 16/4/18.
//  Copyright © 2016年 wansy. All rights reserved.
//

import Foundation
import AlamofireObjectMapper
import Alamofire
import ObjectMapper
import ReachabilitySwift

typealias BusinessFailureClosure = (_ message:String?,_ responseStatus:String) -> Void //业务失败的时候的闭包
typealias RequestFailureClosure = (_ error:Error?) -> Void                             //请求失败的时候的闭包

//详细文档还是好好看看alamfire4.0的文档啊
//https://github.com/Alamofire/Alamofire/blob/master/Documentation/Alamofire%204.0%20Migration%20Guide.md#request-adapter

struct AlaoNetworkConstants {
    
    //webservice notification name
    static let errorNotification        = "webServiceErrorNotification"
    static let tokenOverdueNotification = "webServiceTokenOverdueNotification"
    static let tokenUpdateNotification  = "webServiceToken_Update_Notification"
    
    //token
    static let tokenKey = "TOKEN_KEY"
    
    var token:String {
        get{
            let res = UserDefaults.standard.object(forKey: AlaoNetworkConstants.tokenKey) as? String
            return res ?? ""
        }
        set{
            UserDefaults.standard.set(newValue, forKey: AlaoNetworkConstants.tokenKey)
        }
    }
    
}

class AlaoNetwork {
    
    //one of the Singleton designed
//#if DEBUG // 判断是否在测试环境下
//    let network = AlaoNetwork()
//#else
    static let network = AlaoNetwork()
//#endif
    
    private var headers:[String:String]!
    private init(){
        //... to do some initialization
        headers = [String: String]()
//        headers["source"] = "ios"
//        headers["X-Requested-With"] = "XMLHttpRequest"
    }
    
    //Alamofire manager
    private lazy var defManager: SessionManager = {
        // Set configuration
        let configuration = URLSessionConfiguration.default
        configuration.timeoutIntervalForRequest = AlaoNetworkUtils.timeoutInterval();
        configuration.httpAdditionalHeaders = SessionManager.defaultHTTPHeaders
        
        // Generate manger
        return Alamofire.SessionManager(configuration: configuration)
    }()

    /**
     http请求 （返回对象数组）
     
     - parameter method:            请求类型get／post...
     - parameter URLString:         请求路径
     - parameter parameters:        请求参数
     - parameter businessFailure:   业务失败回调
     - parameter requestFailure:    请求失败回调
     - parameter completionHandler: 成功回调
     */
    func httpRequestArray<T:Mappable>(
        method: Alamofire.HTTPMethod = .get,
        URLString: String,
        parameters: [String: AnyObject]? = nil,
        businessFailure:BusinessFailureClosure? = nil,
        requestFailure:RequestFailureClosure? = nil,
        completionHandler:@escaping ([T]?) -> Void)
    {
        let request = self.alamofireRequest(method: method,URLString: URLString, parameters: parameters,businessFailure: businessFailure,requestFailure:requestFailure)

        if let request = request {
            request.responseObject{ (response: DataResponse<ResultArray<T>>) in
                switch response.result{
                case .success(let resultData):
                    switch ResponseCode.fromRawValue(value: resultData.code){
                    case .success:
                        NotificationCenter.default.post(name: NSNotification.Name(rawValue:AlaoNetworkConstants.errorNotification), object:resultData.message)
                        completionHandler(resultData.data)
                    case .failure:
                        if let businessFailure = businessFailure{
                            businessFailure(resultData.message,ResponseCode.failure.description())
                        }else {
                            NotificationCenter.default.post(name: NSNotification.Name(rawValue:AlaoNetworkConstants.errorNotification), object:resultData.message)
                        }
                    case .tokenExpired:
//                        NSUserDefaults.standardUserDefaults().removeObjectForKey(UserDefaultKeys.TOKEN)
                        NotificationCenter.default.post(name: NSNotification.Name(rawValue:AlaoNetworkConstants.tokenOverdueNotification), object:resultData.message)
                    case .other:
                        NotificationCenter.default.post(name: NSNotification.Name(rawValue:AlaoNetworkConstants.errorNotification), object:resultData.message)
                    }
                case .failure(_):
                    return
                }
            }
        }else{
//            completionHandler(nil)
        }
    }
    
    /**
     http请求 （返回对象）
     
     - parameter method:            请求类型get／post...
     - parameter URLString:         请求路径
     - parameter parameters:        请求参数
     - parameter businessFailure:   业务失败回调
     - parameter requestFailure:    请求失败回调
     - parameter completionHandler: 成功回调
     */
    
    func httpRequest<T:Mappable>(
        method: Alamofire.HTTPMethod = .get,
        URLString: String,
        parameters: [String: AnyObject]? = nil,
        businessFailure:BusinessFailureClosure? = nil,
        requestFailure:RequestFailureClosure? = nil,
        completionHandler:@escaping (T?) -> Void)
    {
        
        let request = self.alamofireRequest(method: method,URLString: URLString, parameters: parameters,businessFailure: businessFailure,requestFailure:requestFailure)
        
        if let request = request {
            request.responseObject{ (response: DataResponse<ResultEntity<T>>) in
                switch response.result{
                case .success(let resultData):
                    switch ResponseCode.fromRawValue(value: resultData.code){
                    case .success:
                        NotificationCenter.default.post(name: NSNotification.Name(rawValue:AlaoNetworkConstants.errorNotification), object:resultData.message)
                        completionHandler(resultData.data)
                    case .failure:
                        if let businessFailure = businessFailure{
                            businessFailure(resultData.message,ResponseCode.failure.description())
                        }else {
                            NotificationCenter.default.post(name: NSNotification.Name(rawValue:AlaoNetworkConstants.errorNotification), object:resultData.message)
                        }
                    case .tokenExpired:
                        //                        NSUserDefaults.standardUserDefaults().removeObjectForKey(UserDefaultKeys.TOKEN)
                        NotificationCenter.default.post(name: NSNotification.Name(rawValue:AlaoNetworkConstants.tokenOverdueNotification), object:resultData.message)
                    case .other:
                        NotificationCenter.default.post(name: NSNotification.Name(rawValue:AlaoNetworkConstants.errorNotification), object:resultData.message)
                    }
                case .failure(_):
                    return
                }
            }
        }else{
            //completionHandler(nil)
        }
    }
    
    /**
     alamofire HTTP request
     
     - parameter method:            请求类型get／post...
     - parameter URLString:         请求路径
     - parameter parameters:        请求参数
     
     - returns: request
     */
    func alamofireRequest(
        method: Alamofire.HTTPMethod = .get,
        URLString: String,
        parameters: [String: AnyObject]?,
        businessFailure:BusinessFailureClosure?,
        requestFailure:RequestFailureClosure?)
        -> DataRequest?
    {
        //Parameters of the log
        var dataLog = "该请求没有参数..."
        if let param = parameters{
            let data = try! JSONSerialization.data(withJSONObject: param, options: .prettyPrinted)
            let strJson = NSString(data: data, encoding: String.Encoding.utf8.rawValue) as String?
            dataLog = self.replaceUnicode(strJson)
        }
        print("\(method.rawValue) DATA:\(dataLog) \nTo Path \(URLString)")
        
        if !self.isReachable() {
            if let requestFailure = requestFailure{
                requestFailure(nil)
            }
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: AlaoNetworkConstants.errorNotification), object: "没有连接网络")
            return nil
        }
        
        //save token to http header
        headers["token"] = AlaoNetworkConstants().token
        
        return defManager.request(AlaoNetworkUtils.createUrl(subPath: URLString)!,
                                  method:method,
                                  parameters: parameters,
                                  encoding: URLEncoding.default,
                                  headers:headers
            ).responseJSON { (response) in
                switch response.result {
                case .success(let value):
                    print("Received:\(self.replaceUnicode((value as AnyObject).description)) \nFrom Path \(URLString)")
                case .failure(let error):
                    print("Received HTTP statusCode:\(response.response?.statusCode ?? -10086)")
                    print("AlaoNetwork Error: \(error.localizedDescription) \nFrom Path \(URLString)")
                    if let requestFailure = requestFailure{
                        requestFailure(error)
                    }else {
                        NotificationCenter.default.post(name:
                            NSNotification.Name(rawValue:AlaoNetworkConstants.errorNotification), object:nil)
                }
            }
        }
    }
    
    /**
     String 值为Unicode格式的字符串编码（如\\u7E8C）转化为中文
     
     - parameter unicodeStr: unicodeStr
     
     - returns: String
     */
    
     func replaceUnicode(_ unicodeStr:String?) -> String{
        guard let unicodeStr = unicodeStr else{return ""}
        
        let tempStr1 = unicodeStr.replacingOccurrences(of: "\\u", with: "\\U")
        let tempStr2 = tempStr1.replacingOccurrences(of:"\"", with: "\\\"")
        let tempStr3 = "\"".appending(tempStr2).appending("\"")
        let tempData = tempStr3.data(using: String.Encoding.utf8)
        let returnStr = try! PropertyListSerialization.propertyList(from: tempData!, options: .mutableContainers, format: nil)
        return (returnStr as! String).replacingOccurrences(of:"\\r\\n", with: "\n")
    }
    
    /**
     判断网络连接情况
     
     - returns: 网络连接情况
     */
    func isReachable() -> Bool{
        let reachability = Reachability.init()
        if let reachability = reachability {
            var reachable = reachability.isReachable
            if !reachable {
                let status = reachability.currentReachabilityStatus
                if status != .notReachable {
                    reachable = true
                }else{
                    reachable = false
                }
            }
            return reachable
        }else {
            print("Unable to create Reachability")
            return false
        }
    }
}
