//
//  Network+Account.swift
//  cln
//
//  Created by wansy on 2017/5/11.
//  Copyright © 2017年 wansy. All rights reserved.
//

import Foundation

extension AlaoNetwork {
    
    /// 发起汇款申请
    ///
    /// - Parameters:
    ///   - params: 参数
    ///   - completionHandler: 回调函数
    func startRemitMoney(params:[String: AnyObject],completionHandler:@escaping (_ result:OrderEntity?) -> Void){
        
        var param = params
        param["startRemitTime"] = Util.getNowTimeInterval() as AnyObject
        param["remitResult"] = "success" as AnyObject
        param["accountJSON"] =      "{'address':'b307e0d6b2d72ce05aec939157580f5a2bb2adfb','crypto':{'cipher':'aes-128-ctr','ciphertext':'d9bc5e7e04365d97d7a6d6cc5cdfe4d35c6c92563ab3092c105de128cb18f097','cipherparams':{'iv':'498c573c6052f3830c212d2271dd8a46'},'kdf':'scrypt','kdfparams':{'dklen':32,'n':262144,'p':1,'r':8,'salt':'527782923e8e192432b6970faa20d0d187ac2c820b1ed630ec4371f0638aebdf'},'mac':'40082c35f19112d485a552ddeea848c33fbcc95c0f216826ec94f6643dbaee25'},'version':3}" as AnyObject
        param["password"] = "123" as AnyObject
        param["publickeys"] = "['04adb2b95849a1c62e3c041973f373e529c8a88eb4a2f4c06ad64b85966f11b69ef51c749a6a5b6b3d82f4bb25b4b1a53870cb3507cb2644aee1dbf81dd840bef4','045f45e5677a6f7a5143ed11896fec86741334517926f9a712bdf114d78cc040983c4c4252ac1bab74538e2740ef87703b3f15cbeaa832be939d1ddda894e91bc6']" as AnyObject
        
        
        self.httpRequest(method: .post,
                      URLString: AlaoURLConstant.Remit.START_REMIT_MONEY,
                     parameters:param)
        { (result) in
            completionHandler(result)
        }
    }
    
    /// 上传清算文件
    ///
    /// - Parameters:
    ///   - fileNo: 文件号（或文件名）
    ///   - completionHandler: 回调函数
    func clearing(ID:String,fileID: String,completionHandler:@escaping (_ result:[RemitMoneyEntity]?) -> Void){
        
        let param = ["ID":ID,"clearingFileID": fileID,"clearingTime": Util.getNowTimeInterval(),
                     "accountJSON" : "{'address':'b307e0d6b2d72ce05aec939157580f5a2bb2adfb','crypto':{'cipher':'aes-128-ctr','ciphertext':'d9bc5e7e04365d97d7a6d6cc5cdfe4d35c6c92563ab3092c105de128cb18f097','cipherparams':{'iv':'498c573c6052f3830c212d2271dd8a46'},'kdf':'scrypt','kdfparams':{'dklen':32,'n':262144,'p':1,'r':8,'salt':'527782923e8e192432b6970faa20d0d187ac2c820b1ed630ec4371f0638aebdf'},'mac':'40082c35f19112d485a552ddeea848c33fbcc95c0f216826ec94f6643dbaee25'},'version':3}" ,"password": "123"]
        
        self.httpRequestArray(method: .post,
                              URLString: AlaoURLConstant.Remit.CLEARING,
                              parameters:param as [String : AnyObject])
        { (result) in
            completionHandler(result)
        }
    }
    
    /// 接收联机汇款报文
    ///
    /// - Parameters:
    ///   - cardNo: 卡号
    ///   - completionHandler: 回调函数
    func recorded(params:[String : AnyObject],completionHandler:@escaping (_ result:[RemitMoneyEntity]?) -> Void){
        
        var param = params
        param["recordedTime"] = Util.getNowTimeInterval() as AnyObject
        param["receiptResult"] = "success" as AnyObject
        param["accountJSON"] =      "{'address':'b307e0d6b2d72ce05aec939157580f5a2bb2adfb','crypto':{'cipher':'aes-128-ctr','ciphertext':'d9bc5e7e04365d97d7a6d6cc5cdfe4d35c6c92563ab3092c105de128cb18f097','cipherparams':{'iv':'498c573c6052f3830c212d2271dd8a46'},'kdf':'scrypt','kdfparams':{'dklen':32,'n':262144,'p':1,'r':8,'salt':'527782923e8e192432b6970faa20d0d187ac2c820b1ed630ec4371f0638aebdf'},'mac':'40082c35f19112d485a552ddeea848c33fbcc95c0f216826ec94f6643dbaee25'},'version':3}" as AnyObject
        param["password"] = "123" as AnyObject
        
        
        self.httpRequestArray(method: .post,
                              URLString: AlaoURLConstant.Remit.RECORDED,
                              parameters:param )
        { (result) in
            completionHandler(result)
        }
    }
    
    /// 接收汇款请求
    ///
    /// - Parameters:
    ///   - cardNo: 卡号
    ///   - completionHandler: 回调函数
    func changeover(cardNo: String,completionHandler:@escaping (_ result:OrderEntity?) -> Void){
        
        let param = ["ID": cardNo, "changeOverTime": Util.getNowTimeInterval(),
                     "changeOverResult":"success",
                     "accountJSON" : "{'address':'b307e0d6b2d72ce05aec939157580f5a2bb2adfb','crypto':{'cipher':'aes-128-ctr','ciphertext':'d9bc5e7e04365d97d7a6d6cc5cdfe4d35c6c92563ab3092c105de128cb18f097','cipherparams':{'iv':'498c573c6052f3830c212d2271dd8a46'},'kdf':'scrypt','kdfparams':{'dklen':32,'n':262144,'p':1,'r':8,'salt':'527782923e8e192432b6970faa20d0d187ac2c820b1ed630ec4371f0638aebdf'},'mac':'40082c35f19112d485a552ddeea848c33fbcc95c0f216826ec94f6643dbaee25'},'version':3}" ,"password": "123"
                     ]
        
        self.httpRequest(method: .post,
                              URLString: AlaoURLConstant.Remit.CHANGEOVER,
                              parameters:param as [String : AnyObject])
        { (result) in
            completionHandler(result)
        }
    }
    
    /// 查询账单
    ///
    /// - Parameters:
    ///   - ID: 账单ID
    ///   - completionHandler: 回调函数
    func getOrder(ID: String,completionHandler:@escaping (_ result:OrderEntity?) -> Void){
        
        let param = ["ID": ID,"accountJSON" : "{'address':'b307e0d6b2d72ce05aec939157580f5a2bb2adfb','crypto':{'cipher':'aes-128-ctr','ciphertext':'d9bc5e7e04365d97d7a6d6cc5cdfe4d35c6c92563ab3092c105de128cb18f097','cipherparams':{'iv':'498c573c6052f3830c212d2271dd8a46'},'kdf':'scrypt','kdfparams':{'dklen':32,'n':262144,'p':1,'r':8,'salt':'527782923e8e192432b6970faa20d0d187ac2c820b1ed630ec4371f0638aebdf'},'mac':'40082c35f19112d485a552ddeea848c33fbcc95c0f216826ec94f6643dbaee25'},'version':3}" ,"password": "123"]
        
        self.httpRequest(method: .post,
                              URLString: AlaoURLConstant.Remit.GET_ORDER,
                              parameters:param as [String : AnyObject])
        { (result) in
            completionHandler(result)
        }
    }
    
    /// 获取交易信息
    ///
    /// - Parameters:
    ///   - completionHandler: 回调函数
    func getTransactionInfo(completionHandler:@escaping (_ result:TransactionInfo?) -> Void){
        
        self.httpRequest(method: .get,
                         URLString: AlaoURLConstant.Remit.TRANSACTION_INFO)
        { (result) in
            completionHandler(result)
        }
    }
    
    /// 查询账单列表
    ///
    /// - Parameters:
    ///   - ID: 账单ID
    ///   - completionHandler: 回调函数
    func getBillList(ID: String?=nil,completionHandler:@escaping (_ result:[OrderEntity]?) -> Void){
        let param = ["accountJSON" : "{'address':'b307e0d6b2d72ce05aec939157580f5a2bb2adfb','crypto':{'cipher':'aes-128-ctr','ciphertext':'d9bc5e7e04365d97d7a6d6cc5cdfe4d35c6c92563ab3092c105de128cb18f097','cipherparams':{'iv':'498c573c6052f3830c212d2271dd8a46'},'kdf':'scrypt','kdfparams':{'dklen':32,'n':262144,'p':1,'r':8,'salt':'527782923e8e192432b6970faa20d0d187ac2c820b1ed630ec4371f0638aebdf'},'mac':'40082c35f19112d485a552ddeea848c33fbcc95c0f216826ec94f6643dbaee25'},'version':3}" ,"password": "123"]
        
        self.httpRequestArray(method: .post,
                         URLString: AlaoURLConstant.Remit.BILL_LIST,
                         parameters:param as [String : AnyObject])
        { (result) in
            completionHandler(result)
        }
    }
    
    /// 获取最近一周的交易量
    ///
    /// - Parameters:
    ///   - completionHandler: 回调函数
    func getTransactionAmount(completionHandler:@escaping (_ result:[DealAmount]?) -> Void){
        
        self.httpRequestArray(method: .get,
                           URLString: AlaoURLConstant.Remit.TRANSACTION_AMOUNT)
        { (result) in
            completionHandler(result)
        }
    }
    
    
    /// 不同状态下的订单数量
    ///
    /// - Parameter completionHandler: 回调函数
    func getBillNum(completionHandler:@escaping (_ result:BillNum?) -> Void){
        
        self.httpRequest(URLString: AlaoURLConstant.Remit.BILL_NUM)
        { (result) in
            completionHandler(result)
        }
    }
    
}
