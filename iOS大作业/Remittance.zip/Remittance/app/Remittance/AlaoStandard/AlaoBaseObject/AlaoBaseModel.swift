//
//  AlaoBaseModel.swift
//  cln
//
//  Created by wansy on 2017/5/11.
//  Copyright © 2017年 wansy. All rights reserved.
//

import Foundation

/* 请求回调状态*/
enum CallBackStatus:Int{
    case bizSuccess = 0   //业务成功
    case bizFailure = 1   //业务失败
    case reqFailure = 2   //请求失败
    case noNetwork  = 3   //无网络连接
}

@objc protocol AlaoModelCallbackDelegate {

    @objc optional func callBackBizSuccess(requestName name:String, object:AnyObject);
    
    @objc optional func callBackBizFailure(requestName name:String, object:AnyObject);
    
    @objc optional func callBackReqFailure(requestName name:String, object:AnyObject);
    
    @objc optional func callbackEternalExecute(object:AnyObject)
}

class AlaoBaseModel:AlaoModelCallbackDelegate{
    
    private var delegate:AlaoModelCallbackDelegate?
    
    lazy var networkManager:AlaoNetwork = AlaoNetwork.network
    
    //convenience 解释：用来进行方便的初始化，就相当于构造函数重载
    convenience init(callBackDelegate delegate:AlaoModelCallbackDelegate){
        self.init()
        self.delegate = delegate
    }
    
    /// 将请求成功结果返回
    ///
    /// - Parameters:
    ///   - name:   请求名称
    ///   - object: 请求返回数据
    func pushCallbackSuccess(requestName name:String,object:AnyObject) {
        
        guard self.delegate != nil else {
            return
        }
        self.delegate!.callBackBizSuccess?(requestName:name,object:object)
        
    }
    
    /// 根据回调状态返回请求结果
    ///
    /// - Parameters:
    ///   - status: 回调状态
    ///   - name:   请求名称
    ///   - object: 请求返回数据
    func pushCallbackStatus(callBackStatus status:CallBackStatus,requestName name:String,object:AnyObject) {
        
        guard self.delegate != nil else {
            return
        }
        
        switch status {
        case .bizSuccess:
            self.delegate!.callBackBizSuccess?(requestName:name,object:object)
        case .bizFailure:
            self.delegate!.callBackBizFailure?(requestName:name,object:object)
        case .reqFailure:
            self.delegate!.callBackReqFailure?(requestName:name,object:object)
        default:
            break
        }
        
    }
    
    /// 返回没网的时候的情况
    ///
    /// - Parameters:
    ///   - status: 回调状态
    ///   - object: 请求返回数据
    func eternalExecuteNoNetWork(callBackStatus status:CallBackStatus,object:AnyObject) {
        
        if status == .noNetwork && self.delegate != nil{
            self.delegate!.callbackEternalExecute?(object:object)
        }
        
    }
}
