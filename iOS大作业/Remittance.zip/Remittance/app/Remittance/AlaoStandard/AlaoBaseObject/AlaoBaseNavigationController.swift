//
//  AlaoBaseNavigationController.swift
//  cln
//
//  Created by wansy on 2017/5/15.
//  Copyright © 2017年 wansy. All rights reserved.
//

import Foundation
import UIKit

class AlaoBaseNavigationController : UINavigationController {
    
     override func pushViewController(_ viewController: UIViewController, animated: Bool){
        
        if self.childViewControllers.count != 0 {
            viewController.hidesBottomBarWhenPushed = true
            
        }
        super.pushViewController(viewController, animated: animated)
    }
}
