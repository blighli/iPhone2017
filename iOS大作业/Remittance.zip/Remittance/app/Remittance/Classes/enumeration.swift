//
//  enumeration.swift
//  Remittance
//
//  Created by wansy on 2017/9/24.
//  Copyright © 2017年 wansy. All rights reserved.
//

/* 机构类型 */
enum OrganType:Int{
    case remit       = 0      // 汇出机构
    case changeOver  = 1      // 转接机构
    case `import`    = 2      // 汇入机构
    case clearing    = 3      // 清算机构
    
    static func fromRawValue(raw : Int) -> OrganType{
        switch raw {
        case OrganType.remit.rawValue:
            return .remit
        case OrganType.changeOver.rawValue:
            return .changeOver
        case OrganType.`import`.rawValue:
            return .`import`
        case OrganType.clearing.rawValue:
            return .clearing
        default:
            return .remit;
        }
    }
    
    func organImageName() -> String {
        switch self {
        case .remit:
            return "CIBC_profile"
        case .import:
            return "BOC_profile"
        case .changeOver:
            return "UP_profile"
        case .clearing:
            return "UP_profile"
        }
    }
    
    func organDetailName() -> String {
        switch self {
        case .remit:
            return "CIBC"
        case .import:
            return "BOC"
        case .changeOver:
            return "Unionpay"
        case .clearing:
            return "Unionpay"
        }
    }
    
    func organName() -> String {
        switch self {
        case .remit:
            return "Remitting INST"
        case .import:
            return "Paying INST"
        case .changeOver:
            return "Transfer INST"
        case .clearing:
            return "Liquidation INST"
        }
    }
}

enum RemittanceType: String {
    case remited     = "To Transfer"
    case changOvered = "To Recorded"
    case imported    = "To Liquidate"
    case cleared     = "Liquidated"
    
    func description() -> String{
        switch self {
        case .remited:
            return "已汇出"
        case .changOvered:
            return "已转接"
        case .imported:
            return "已汇入"
        case .cleared:
            return "已结清"
        }
    }
    
    func imageName() -> String{
        switch self {
        case .remited:
            return "To transfer"
        case .changOvered:
            return "To Remittance"
        case .imported:
            return "To clear"
        case .cleared:
            return "Cleared-1"
        }
    }
    
    static func getState (_ order:OrderEntity?) -> RemittanceType{
        guard let order = order else {
            return .remited
        }
        
        if order.clearingTime != "" {
            return .cleared
        }else if order.recordedTime != "" {
            return .imported
        }else if order.changeOverTime != "" {
            return .changOvered
        }else {
            return .remited
        }
    }
    
}

