//
//  SearchViewController.swift
//  Remittance
//
//  Created by wansy on 2017/9/22.
//  Copyright © 2017年 wansy. All rights reserved.
//

import UIKit

class SearchViewController: UIViewController,UITextFieldDelegate,UITableViewDelegate,UITableViewDataSource {

    @IBOutlet weak var searchTextField: AlaoTextField!
    @IBOutlet weak var cancelBtn: UIButton!
    @IBOutlet weak var bgView: UIView!
    @IBOutlet weak var billTableView: UITableView!
    
    var billArray:[OrderEntity] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

        searchTextField.delegate = self
        bgView.layer.borderWidth = 1
        bgView.layer.borderColor = Color().color(hex: 0xdddddd, alpha: 0.6).cgColor
        
        billTableView.register(UINib(nibName: "BillTableViewCell", bundle: nil), forCellReuseIdentifier: BillTableViewCell.cellId)
        billTableView.rowHeight = 130
        billTableView.tableFooterView = UIView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.isHidden = true
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.navigationBar.isHidden = false
    }
    
    @IBAction func cancel(_ sender: UIButton) {
        
        guard searchTextField.text != "" else {
            self.dismiss(animated: true, completion: nil)
            return
        }
        
        self.getBillList(conditionStr: searchTextField.text!)
    }
    
    func getBillList (conditionStr: String) {
        
//      从本地数据中查找
        self.showHUDWithTitle(tips: "Searching...")
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.3) {
            self.hideHUD()
            let billArr = ArchiveData.archiveData.allOrder
            var result:[OrderEntity] = []
            for order in billArr {
                if order.orderID.components(separatedBy: conditionStr).count > 1{
                    result.append(order)
                }
            }
            
            self.billArray = result
            self.billTableView.reloadData()

        }
        
//        从后台请求
//        self.showHUDWithTitle(tips: "Searching...")
//        AlaoNetwork.network.getBillList { (res) in
//            guard res != nil else {
//                return
//            }
//            var result:[OrderEntity] = []
//            for order in res! {
//                if order.orderID.components(separatedBy: conditionStr).count > 1{
//                    result.append(order)
//                }
//            }
//            
//            self.billArray = result
//            self.billTableView.reloadData()
//        }
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let existingString: NSString = textField.text! as NSString
        let candidateString =  existingString.replacingCharacters(in: range, with: string)
        
        cancelBtn.setTitle(candidateString != "" ? "Search" : "Cancel", for: .normal)
        return true
    }
    
    // MARK: - UITableViewDelegate,UITableViewDataSource
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.billArray.count;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = BillTableViewCell.cellInTableView(tableView: tableView)
        cell.data = self.billArray[(self.billArray.count - 1) - indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let billDetailVC = self.viewControllerInStoryboard(storyboardName: "Main", vcIdentifier: "BillDetailVC") as! BillDetailViewController
        billDetailVC.orderDetail = self.billArray[(self.billArray.count - 1) - indexPath.row]
        self.navigationController!.pushViewController(billDetailVC, animated: true)
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        if self.billArray.count != 0 {
            return nil
        }else {
            let noRecordView = NoRecordView.noRecordView()
            return noRecordView
        }
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if self.billArray.count == 0 {
            return 260
        }else {
            return 0
        }
    }
}
