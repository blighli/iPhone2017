//
//  AlaoTextField.swift
//  Remittance
//
//  Created by wansy on 2017/9/22.
//  Copyright © 2017年 wansy. All rights reserved.
//

import UIKit

class AlaoTextField: UITextField {

    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        self.attributedPlaceholder = NSAttributedString.init(string: self.placeholder ?? "", attributes: [NSForegroundColorAttributeName:Color().color(hex: 0xffffff, alpha: 0.6)])
    }

}
