//
//  DealViewController.swift
//  Remittance
//
//  Created by wansy on 2017/9/20.
//  Copyright © 2017年 wansy. All rights reserved.
//

import UIKit

class DealViewController: BaseViewController, UITableViewDelegate,UITableViewDataSource {

    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var dealNumLabel: UILabel!
    @IBOutlet weak var blockNumLabel: UILabel!
    @IBOutlet weak var nodeNumLabel: UILabel!
    
    var pushController:((_ bill:OrderEntity)->())!
    var billArray:[OrderEntity] = []{
        didSet {
            let transactionInfo = ArchiveData.archiveData.transactionInfo
            self.dealNumLabel.text = "\(String(describing: transactionInfo.transactionNum!))"
            self.blockNumLabel.text = "\(String(describing: transactionInfo.blockNum!))"
            self.nodeNumLabel.text = transactionInfo.nodeNum!
            AlaoNetwork.network.getTransactionInfo { (res) in
                guard res != nil else {
                    return
                }
                ArchiveData.archiveData.transactionInfo = res!
                self.dealNumLabel.text = "\(String(describing: res!.transactionNum!))"
                self.blockNumLabel.text = "\(String(describing: res!.blockNum!))"
                self.nodeNumLabel.text = res!.nodeNum
            }
            
            guard tableView != nil else {
                return
            }
            tableView.reloadData()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.setupTableView()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidLoad()
        tableView.reloadData()
    }
    
    private func setupTableView () {
        
        tableView.register(UINib(nibName: "BillTableViewCell", bundle: nil) , forCellReuseIdentifier: BillTableViewCell.cellId)
        tableView.rowHeight = 130
        tableView.tableFooterView = UIView()
        
    }
    
    //MARK: - UITableViewDelegate,UITableViewDataSource
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.billArray.count;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = BillTableViewCell.cellInTableView(tableView: tableView)
        cell.data = self.billArray[(self.billArray.count - 1) - indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        pushController(self.billArray[(self.billArray.count - 1) - indexPath.row])
    }

    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        if self.billArray.count != 0 {
            return nil
        }else {
            let noRecordView = NoRecordView.noRecordView()
            return noRecordView
        }
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if self.billArray.count == 0 {
            return 260
        }else {
            return 0
        }
    }
}
