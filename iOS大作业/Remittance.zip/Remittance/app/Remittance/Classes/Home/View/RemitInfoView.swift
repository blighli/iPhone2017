//
//  RemitInfoVIew.swift
//  Remittance
//
//  Created by wansy on 2017/9/26.
//  Copyright © 2017年 wansy. All rights reserved.
//

import UIKit

class RemitInfoView: UIView {
    
    @IBOutlet weak var bgView: UIView!
    
    class func remitInfoView() -> RemitInfoView {
        return Bundle.main.loadNibNamed("RemitInfoView", owner: nil, options: nil)?.last as! RemitInfoView
    }

}
