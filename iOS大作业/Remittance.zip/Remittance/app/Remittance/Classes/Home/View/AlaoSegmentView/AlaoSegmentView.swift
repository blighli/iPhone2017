//
//  AlaoSegmentView.swift
//  AlaoSegment
//
//  Created by wansy on 2017/9/15.
//  Copyright © 2017年 wansy. All rights reserved.
//

import UIKit

class AlaoSegmentView: UIView,UIPageViewControllerDataSource,UIPageViewControllerDelegate,UIScrollViewDelegate {

    var subViewControllers = [UIViewController]()
    {
        didSet
        {
            if self.subViewControllers.count > 0
            {
                self.pageViewController.setViewControllers([self.subViewControllers[0]], direction: UIPageViewControllerNavigationDirection.forward, animated: false, completion: nil)
            }
        }
    }
    
    var headView:AlaoSegmentHeader!
    {
        didSet
        {
            self.headView.setHeadTitles(getTitles())
            
            self.headView.didClick =
                {
                    let subVCs = self.subViewControllers as NSArray
                    let direction:UIPageViewControllerNavigationDirection = self.headView.selectedButtonIndex > subVCs.index(of: self.pageViewController.viewControllers![self.pageViewController.viewControllers!.count - 1]) ?UIPageViewControllerNavigationDirection.forward : UIPageViewControllerNavigationDirection.reverse
                    
                    self.pageViewController.setViewControllers([self.selectedController()], direction: direction, animated: true, completion: nil)
            }
        }
    }
    
    fileprivate var pageViewController:UIPageViewController!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }
    
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
        setup()
    }
    
    fileprivate func setup()
    {
        self.pageViewController = UIPageViewController(transitionStyle: UIPageViewControllerTransitionStyle.scroll, navigationOrientation: UIPageViewControllerNavigationOrientation.horizontal, options: nil)
        self.pageViewController.view.frame = self.bounds
        self.pageViewController.dataSource = self
        self.pageViewController.delegate = self
        self.pageViewController.view.autoresizingMask = ([UIViewAutoresizing.flexibleWidth , UIViewAutoresizing.flexibleHeight])
        self.addSubview(pageViewController.view)
        
        let scrollerView:UIScrollView = self.pageViewController.view.subviews[0] as! UIScrollView
        scrollerView.delegate = self as UIScrollViewDelegate
    }
    
    fileprivate func getTitles() -> [String]
    {
        var titles = [String]()
        for vc in self.subViewControllers
        {
            let title = vc.title ?? "视图"
            titles.append(title)
        }
        return titles
    }
    
    fileprivate func selectedController() -> UIViewController
    {
        return self.subViewControllers[self.headView!.selectedButtonIndex]
    }
    
    // MARK: - UIPageViewControllerDataSource,UIPageViewControllerDelegate
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        let subVCs = self.subViewControllers as NSArray
        var index:Int = subVCs.index(of: viewController)
        
        if index == 0
        {
            return nil
        }
        index = index - 1;
        return self.subViewControllers[index]
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        let subVCs = self.subViewControllers as NSArray
        var index:Int = subVCs.index(of: viewController)
        
        if index+1 >= self.subViewControllers.count
        {
            return nil
        }
        index = index + 1;
        return self.subViewControllers[index]
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, didFinishAnimating finished: Bool, previousViewControllers: [UIViewController], transitionCompleted completed: Bool) {
        if !completed
        {
            return
        }
        
        let subVCs = self.subViewControllers as NSArray
        self.headView.selectedButtonIndex = subVCs.index(of: pageViewController.viewControllers![pageViewController.viewControllers!.count - 1])
    }
    
    // MARK: - UIScrollViewDelegate
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
//      scrollView.bounces = (scrollView.contentOffset.y <= 0) ? false : true;
        
        let xOffset = scrollView.contentOffset.x - self.bounds.width
        
        if (self.headView.selectedButtonIndex == 0 && xOffset < 0) ||
            (self.headView.selectedButtonIndex == subViewControllers.count - 1 && xOffset > 0) {
            return
        }
        
        self.headView.updateSliderFrame(xOffset)
    }
}

