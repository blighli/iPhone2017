//
//  AlaoSegmentHeader.swift
//  AlaoSegment
//
//  Created by wansy on 2017/9/15.
//  Copyright © 2017年 wansy. All rights reserved.
//

import UIKit

fileprivate let offsetXRate:CGFloat = 0.27
fileprivate let slideDuration:TimeInterval = 0.4
fileprivate let btnRate:CGFloat = 0.85

class AlaoSegmentHeader: UIView {
    
    var selectedTitleColor:UIColor?
    var normalTitleColor:UIColor?
    var bottomColor:UIColor?
    var hiddenBottom:Bool = false
    
    var didClick: (()->())?
    var selectedButtonIndex:Int!
    {
        get
        {
            let subButtons = self.buttonView.subviews as NSArray
            return subButtons.index(of: self.selectedHeadButton!)
        }
        set
        {
            let headButton:UIButton = self.buttonView.subviews[newValue] as! UIButton
            turnSelectButton(headButton)
        }
    }
    
    fileprivate var selectedHeadButton:UIButton?
    fileprivate var buttonView:UIView!
    fileprivate var bottomView:UIView!
    fileprivate var slideLabel:UILabel!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }
    
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
        setup()
    }
    
    fileprivate func setup()
    {
        self.buttonView = UIView()
        self.addSubview(self.buttonView)
        
        self.bottomView = UIView()
        self.addSubview(self.bottomView)
        
        self.slideLabel = UILabel()
        self.addSubview(self.slideLabel)
        
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        let viewH:CGFloat = self.frame.size.height
        let viewW:CGFloat = self.frame.size.width
        
        //按钮view布局
        self.buttonView.frame = CGRect(x: 0,
                                       y: 0,
                                       width: viewW,
                                       height: viewH * btnRate)
        
        
        //底部view布局
        self.bottomView.frame = CGRect(x: 0,
                                       y: viewH * btnRate,
                                       width: viewW,
                                       height: viewH * (1 - btnRate))
        
    }
    
    fileprivate func addHeadButton(_ title:String?)
    {
        let headButton = UIButton()
        
        headButton.setTitle(title, for: UIControlState())
        headButton.setTitleColor(self.normalTitleColor ?? UIColor.black, for: UIControlState())
        headButton.setTitleColor(self.selectedTitleColor ?? UIColor.orange, for: UIControlState.selected)
        
        headButton.addTarget(self, action:#selector(AlaoSegmentHeader.buttonClick(_:)), for: UIControlEvents.touchUpInside)
        if self.selectedHeadButton == nil
        {
            self.selectedHeadButton = headButton
            if self.hiddenBottom == false
            {
                self.slideLabel.backgroundColor = self.bottomColor ?? UIColor.orange
            }
            self.selectedHeadButton!.isSelected = true
        }
        
        self.buttonView.addSubview(headButton)
    }
    
    func buttonClick(_ button:UIButton)
    {
        if self.selectedHeadButton != button
        {
            turnSelectButton(button)
        }
        
        if let didClick = self.didClick
        {
            didClick()
        }
    }
    
    fileprivate func turnSelectButton(_ button:UIButton)
    {
        if self.hiddenBottom == false
        {
            UIView.animate(withDuration: slideDuration, animations: { () -> Void in
                
                let labelX:CGFloat = button.frame.origin.x + button.frame.size.width * offsetXRate
                let labelY:CGFloat = button.frame.size.height
                let labelW:CGFloat = self.slideLabel.bounds.size.width
                let labelH:CGFloat = self.slideLabel.bounds.size.height
                
                self.slideLabel.frame = CGRect(x: labelX,
                                               y: labelY,
                                               width: labelW,
                                               height: labelH)
            })
        }
        
        self.selectedHeadButton!.isSelected = false
        button.isSelected = true
        self.selectedHeadButton = button
    }
    
    internal func setHeadTitles(_ titles:[String])
    {
        for title in titles
        {
            addHeadButton(title)
        }
        
        let viewH:CGFloat = self.frame.size.height
        let viewW:CGFloat = self.frame.size.width
        let buttonViews = self.buttonView.subviews as NSArray
        let headButtonW:CGFloat = viewW / CGFloat(self.buttonView.subviews.count)
        
        //按钮布局
        buttonViews.enumerateObjects({ (object: Any!, idx: Int, stop: UnsafeMutablePointer<ObjCBool>) in
            let headButton = object as! UIButton
            let headButtonX:CGFloat =  CGFloat(idx) * headButtonW
            headButton.titleLabel?.font =  UIFont.systemFont(ofSize: 16)
            headButton.frame = CGRect(x: headButtonX,
                                      y: 0,
                                      width: headButtonW ,
                                      height: self.buttonView.bounds.size.height)
        })
        
        //滑块布局
        self.slideLabel.frame = CGRect(x: headButtonW * offsetXRate,
                                       y: viewH * btnRate,
                                       width: headButtonW * (1 - 2 * offsetXRate),
                                       height: viewH * (1 - btnRate))
        self.slideLabel.layer.cornerRadius = 2.5 //self.slideLabel.bounds.height * 0.5
        self.slideLabel.layer.masksToBounds = true
    }
    
    // MARK: - update slider frame
    
    internal func updateSliderFrame(_ xOffset:CGFloat) {
        
        let zeroZoneWidth = UIScreen.main.bounds.width * 0.5
        let subButtonWitdh = self.buttonView.bounds.width  / CGFloat(self.buttonView.subviews.count)
        let initX = subButtonWitdh * CGFloat(self.selectedButtonIndex) + subButtonWitdh * offsetXRate
        if xOffset > 0 {
            if xOffset < zeroZoneWidth {
                let variationWitdh = subButtonWitdh * xOffset / zeroZoneWidth
                self.slideLabel.frame.size.width = subButtonWitdh * (1 - offsetXRate * 2)  + variationWitdh
            }else {
                let variationWitdh = subButtonWitdh * (xOffset - zeroZoneWidth) / zeroZoneWidth
                self.slideLabel.frame.size.width = (subButtonWitdh * 2 * (1 - offsetXRate)) - variationWitdh
                self.slideLabel.frame.origin.x = initX + variationWitdh
            }
        }else if xOffset != 0.0 {
            if -xOffset < zeroZoneWidth {
                let variationWitdh = subButtonWitdh * xOffset / zeroZoneWidth
                self.slideLabel.frame.origin.x = initX + variationWitdh
                self.slideLabel.frame.size.width = subButtonWitdh * (1 - offsetXRate * 2) - variationWitdh
            }else {
                self.slideLabel.frame.origin.x = subButtonWitdh * CGFloat(self.selectedButtonIndex - 1) + subButtonWitdh * offsetXRate
                let variationWitdh = subButtonWitdh * (-xOffset - zeroZoneWidth) / zeroZoneWidth
                self.slideLabel.frame.size.width = (subButtonWitdh * 2 * (1 - offsetXRate)) - variationWitdh
            }
        }
    }
}
