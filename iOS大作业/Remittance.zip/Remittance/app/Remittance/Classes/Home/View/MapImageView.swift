//
//  MapImageView.swift
//  Remittance
//
//  Created by wansy on 2017/9/26.
//  Copyright © 2017年 wansy. All rights reserved.
//

import UIKit

class MapImageView: UIImageView {
    
    private var gradientLayer: CAGradientLayer!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.setup()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.setup()
    }
    
    func setup() {
        self.createGradientLayer()
    }
    
    func startAnimation() {
        let layer = getLayer()
        layer.add(self.animation(), forKey: "strokeEndAnimation")
        gradientLayer.mask = layer
        self.layer.addSublayer(gradientLayer)
    }
    
    func removeLayer () {
        gradientLayer.removeFromSuperlayer()
    }
    
    func createGradientLayer() {
        gradientLayer = CAGradientLayer()
        gradientLayer.frame = CGRect(x:0,
                                     y:0,
                                     width:self.bounds.width,
                                     height:self.bounds.height)
        
        gradientLayer.startPoint = CGPoint(x:0.8 ,y:0.5)
        gradientLayer.endPoint = CGPoint(x:0.2 ,y:0.5)

        //设置渐变的主颜色
        gradientLayer.colors = [Color().color(hex: 0x62A9ED).cgColor, Color().color(hex: 0x3370D6).cgColor]
    }
    
    func getLayer() -> CAShapeLayer{
        let path = UIBezierPath()
    
        path.move(to: CGPoint(x:296, y:69))
        path.addQuadCurve(to: CGPoint(x:83, y:144), controlPoint: CGPoint(x:170, y:30))
        path.addQuadCurve(to: CGPoint(x:73, y:125), controlPoint: CGPoint(x:78, y:70))
        
        let layer = CAShapeLayer()
        layer.path = path.cgPath
        layer.fillColor = UIColor.clear.cgColor
        layer.strokeColor = UIColor.red.cgColor
        layer.lineWidth = 3
        layer.lineCap = "round"
        layer.strokeStart = 0.0
    
        return layer
    }
    
    func animation () -> CABasicAnimation{
        let pathAnimation = CABasicAnimation(keyPath: "strokeEnd")
    
        pathAnimation.duration = 2.0
        pathAnimation.timingFunction = CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseInEaseOut)
        pathAnimation.fromValue = 0.0
        pathAnimation.toValue = 1.0
        pathAnimation.fillMode = kCAFillModeForwards
        pathAnimation.isRemovedOnCompletion = false
    
        return pathAnimation
    }
    
}
