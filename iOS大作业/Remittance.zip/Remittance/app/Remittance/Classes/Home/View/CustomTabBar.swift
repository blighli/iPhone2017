//
//  CustomTabBar.swift
//  Remittance
//
//  Created by wansy on 2017/9/21.
//  Copyright © 2017年 wansy. All rights reserved.
//

import UIKit

class CustomTabBar: UITabBar,UITabBarDelegate {
    
    var bgViews = [UIView]()
    
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
        
        if #available(iOS 10.0, *) {
            self.unselectedItemTintColor = UIColor.white
        } else {
            for item in self.items! {
                let image = item.image!
                item.image = image.withRenderingMode(.alwaysOriginal)
            }
        }
        
        self.setupSubviews()
    }
    
    private func setupSubviews() {
        let bgView1 = UIView()
        self.insertSubview(bgView1, at: 0)
        
        let bgView2 = UIView()
        self.insertSubview(bgView2, at: 0)
        bgViews = [bgView1, bgView2]
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        let viewH = self.bounds.height
        let viewW = self.bounds.width
        let bgViewW = viewW / CGFloat(bgViews.count)
        
        for (index, bgView) in bgViews.enumerated() {
            
            bgView.frame = CGRect(x: CGFloat(index) * bgViewW,
                                  y: 0,
                                  width: bgViewW,
                                  height: viewH)
            
            if index == 0 {
                bgView.backgroundColor = Color().color(hex: 0x2d3851)
            }else {
                bgView.backgroundColor = Color().color(hex: 0x56677e)
            }
        }
    }

}
