//
//  TransactionInfo.swift
//  Remittance
//
//  Created by wansy on 2017/9/28.
//  Copyright © 2017年 wansy. All rights reserved.
//

import ObjectMapper

class TransactionInfo: NSObject, Mappable,NSCoding {
    
    var transactionNum: Int?
    var transactionDuration: String?
    var blockNum: Int?
    var nodeNum: String?
    
    required init?(map: Map) {
        
    }
    
    init(transactionNum: Int = 0, transactionDuration:String = "0", blockNum:Int = 0, nodeNum:String = "0") {
        super.init()
        self.transactionNum = transactionNum
        self.transactionDuration = transactionDuration
        self.blockNum = blockNum
        self.nodeNum = nodeNum
    }
    
    func mapping(map: Map) {
        
        transactionNum      <- map["transactionNum"]
        transactionDuration <- map["transactionDuration"]
        blockNum            <- map["blockNum"]
        nodeNum             <- map["nodeNum"]
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init()
        transactionNum      = aDecoder.decodeObject(forKey: "transactionNum") as? Int
        transactionDuration = aDecoder.decodeObject(forKey: "transactionDuration") as? String
        blockNum            = aDecoder.decodeObject(forKey: "blockNum") as? Int
        nodeNum             = aDecoder.decodeObject(forKey: "nodeNum") as? String
    }
    
    func encode(with aCoder: NSCoder) {
        aCoder.encode(transactionNum, forKey: "transactionNum")
        aCoder.encode(transactionDuration, forKey: "transactionDuration")
        aCoder.encode(blockNum, forKey: "blockNum")
        aCoder.encode(nodeNum, forKey: "nodeNum")
    }
}
