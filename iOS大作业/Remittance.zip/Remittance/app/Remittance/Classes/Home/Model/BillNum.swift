//
//  BillNum.swift
//  Remittance
//
//  Created by wansy on 2017/9/29.
//  Copyright © 2017年 wansy. All rights reserved.
//

import ObjectMapper

class BillNum: NSObject, Mappable,NSCoding {
    
    var toChangeoverNum: Int?
    var toImportNum: Int?
    var ToClearingNum: Int?
    var cleared: Int?
    
    init(toChangeoverNum: Int = 0, toImportNum: Int = 0, ToClearingNum: Int = 0, cleared: Int = 0) {
        super.init()
        self.toChangeoverNum = toChangeoverNum
        self.toImportNum = toImportNum
        self.ToClearingNum = ToClearingNum
        self.cleared = cleared
    }
    
    required init?(map: Map) {
        
    }
    
    func mapping(map: Map) {
        
        toChangeoverNum <- map["toChangeoverNum"]
        toImportNum     <- map["toImportNum"]
        ToClearingNum   <- map["ToClearingNum"]
        cleared         <- map["cleared"]
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        toChangeoverNum = aDecoder.decodeObject(forKey: "toChangeoverNum") as? Int
        toImportNum     = aDecoder.decodeObject(forKey: "toImportNum") as? Int
        ToClearingNum   = aDecoder.decodeObject(forKey: "ToClearingNum") as? Int
        cleared         = aDecoder.decodeObject(forKey: "cleared") as? Int
    }
    
    func encode(with aCoder: NSCoder) {
        aCoder.encode(toChangeoverNum, forKey: "toChangeoverNum")
        aCoder.encode(toImportNum, forKey: "toImportNum")
        aCoder.encode(ToClearingNum, forKey: "ToClearingNum")
        aCoder.encode(cleared, forKey: "cleared")
    }
    
}
