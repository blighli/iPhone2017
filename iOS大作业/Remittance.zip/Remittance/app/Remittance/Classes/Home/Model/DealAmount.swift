//
//  DealAmount.swift
//  Remittance
//
//  Created by wansy on 2017/9/29.
//  Copyright © 2017年 wansy. All rights reserved.
//

import UIKit
import ObjectMapper

class DealAmount: Mappable {
    
    var transactionAmount: Int = 0
    
    required init?(map: Map) {
        
    }
    
    func mapping(map: Map) {
        
        transactionAmount <- map["transactionAmount"]
        
    }
}
