//
//  RemitMoneyEntity.swift
//  Remittance
//
//  Created by wansy on 2017/7/5.
//  Copyright © 2017年 wansy. All rights reserved.
//

import UIKit
import ObjectMapper

class RemitMoneyEntity: Mappable {
    
    var type: String = ""
    var value: String = ""
    var mayvalue: String = ""
    
    required init?(map: Map) {
        
    }
    
    func mapping(map: Map) {
        
        type     <- map["type"]
        value    <- map["value"]
        mayvalue <- map["mayvalue"]
        
    }
}
