//
//  OrderEntity.swift
//  Remittance
//
//  Created by wansy on 2017/7/6.
//  Copyright © 2017年 wansy. All rights reserved.
//

import ObjectMapper

class OrderEntity: NSObject, Mappable,NSCoding {
    
    var amount: String = ""
    var changeOverResult: String = ""
    var changeOverTime: String = ""
    var clearingTime: String = ""
    var currency: String = ""
    var orderID: String = ""
    var payeeName: String = ""
    var receiptResult: String = ""
    var recordedTime: String = ""
    var remitAgency: String = ""
    var remitPostscript: String = ""
    var remitResult: String = ""
    var remitterAddress: String = ""
    var remitterContact: String = ""
    var remitterCountry: String = ""
    var remitterName: String = ""
    var serialNumber: String = ""
    var startRemitTime: String = ""
    var symmetricKey: String = ""
    
    override init() {
        super.init()
    }
    
    required init?(map: Map) {
        
    }
    
    func mapping(map: Map) {
        
        amount           <- map["amount"]
        changeOverResult <- map["changeOverResult"]
        changeOverTime   <- map["changeOverTime"]
        clearingTime     <- map["clearingTime"]
        currency         <- map["currency"]
        orderID          <- map["orderID"]
        payeeName        <- map["payeeName"]
        receiptResult    <- map["receiptResult"]
        recordedTime     <- map["recordedTime"]
        remitAgency      <- map["remitAgency"]
        remitPostscript  <- map["remitPostscript"]
        remitResult      <- map["remitResult"]
        remitterAddress  <- map["remitterAddress"]
        remitterContact  <- map["remitterContact"]
        remitterCountry  <- map["remitterCountry"]
        remitterName     <- map["remitterName"]
        serialNumber     <- map["serialNumber"]
        startRemitTime   <- map["startRemitTime"]
        symmetricKey     <- map["symmetricKey"]
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        super.init()
        
        amount           = aDecoder.decodeObject(forKey: "amount") as! String
        changeOverResult = aDecoder.decodeObject(forKey: "changeOverResult") as! String
        changeOverTime   = aDecoder.decodeObject(forKey: "changeOverTime") as! String
        clearingTime     = aDecoder.decodeObject(forKey: "clearingTime") as! String
        currency         = aDecoder.decodeObject(forKey: "currency") as! String
        orderID          = aDecoder.decodeObject(forKey: "orderID") as! String
        payeeName        = aDecoder.decodeObject(forKey: "payeeName") as! String
        receiptResult    = aDecoder.decodeObject(forKey: "receiptResult") as! String
        recordedTime     = aDecoder.decodeObject(forKey: "recordedTime") as! String
        remitAgency      = aDecoder.decodeObject(forKey: "remitAgency") as! String
        remitPostscript  = aDecoder.decodeObject(forKey: "remitPostscript") as! String
        remitResult      = aDecoder.decodeObject(forKey: "remitResult") as! String
        remitterAddress  = aDecoder.decodeObject(forKey: "remitterAddress") as! String
        remitterContact  = aDecoder.decodeObject(forKey: "remitterContact") as! String
        remitterCountry  = aDecoder.decodeObject(forKey: "remitterCountry") as! String
        remitterName     = aDecoder.decodeObject(forKey: "remitterName") as! String
        serialNumber     = aDecoder.decodeObject(forKey: "serialNumber") as! String
        startRemitTime   = aDecoder.decodeObject(forKey: "startRemitTime") as! String
        symmetricKey     = aDecoder.decodeObject(forKey: "symmetricKey") as! String
    }
    
    func encode(with aCoder: NSCoder) {
        aCoder.encode(amount, forKey: "amount")
        aCoder.encode(changeOverResult, forKey: "changeOverResult")
        aCoder.encode(changeOverTime, forKey: "changeOverTime")
        aCoder.encode(clearingTime, forKey: "clearingTime")
        aCoder.encode(currency, forKey: "currency")
        aCoder.encode(orderID, forKey: "orderID")
        aCoder.encode(payeeName, forKey: "payeeName")
        aCoder.encode(receiptResult, forKey: "receiptResult")
        aCoder.encode(recordedTime, forKey: "recordedTime")
        aCoder.encode(remitAgency, forKey: "remitAgency")
        aCoder.encode(remitPostscript, forKey: "remitPostscript")
        aCoder.encode(remitResult, forKey: "remitResult")
        aCoder.encode(remitterAddress, forKey: "remitterAddress")
        aCoder.encode(remitterContact, forKey: "remitterContact")
        aCoder.encode(remitterCountry, forKey: "remitterCountry")
        aCoder.encode(remitterName, forKey: "remitterName")
        aCoder.encode(serialNumber, forKey: "serialNumber")
        aCoder.encode(startRemitTime, forKey: "startRemitTime")
        aCoder.encode(symmetricKey, forKey: "symmetricKey")
    }

}
