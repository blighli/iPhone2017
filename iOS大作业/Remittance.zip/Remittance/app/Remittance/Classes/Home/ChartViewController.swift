//
//  ChartViewController.swift
//  Remittance
//
//  Created by wansy on 2017/9/27.
//  Copyright © 2017年 wansy. All rights reserved.
//

import UIKit

let chartHeight:CGFloat = 330
let headerPadding:CGFloat = 20
let footerViewHeight:CGFloat = 35


class ChartViewController: UIViewController, JBLineChartViewDelegate, JBLineChartViewDataSource{

    var day = ["09-11","09-12","09-13","09-14","09-15","09-16","09-17"]
    var lineValue:[[CGFloat]] = [[0.6, 0.4, 0.3, 0.4, 0.3, 0.7, 0.8],[0.35, 0.15, 0.05, 0.15, 0.05, 0.45, 0.55]]
    
    var lineChartView: JBLineChartView!
    var headerView: UIView!
    var tipLabel:UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setupChartView()
        
//        self.showHUDWithTitle(tips: "loading...")
//        AlaoNetwork.network.getTransactionAmount { (res) in
//            
//        }
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.lineChartView.setState(.expanded, animated: true)
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        self.lineChartView.setState(.collapsed, animated: true)
    }
    
    func setupChartView () {
        
        lineChartView = JBLineChartView()
        lineChartView.frame = CGRect(x: 0, y: 0,width:self.view.bounds.width,height:chartHeight)
        lineChartView.delegate = self
        lineChartView.dataSource = self
        
        lineChartView.headerPadding = headerPadding;
        lineChartView.footerView = self.footerView()
        self.creatHeaderView()
        self.creatTipView()
        lineChartView.headerView = headerView
        self.view.addSubview(lineChartView)
        
        lineChartView.reloadData()
    }
    
    func footerView () -> UIView {
        let footerView = UIView()
        let labelW = self.view.bounds.width / 7.0
        for index in 0...6 {
            let label = UILabel()
            label.font = UIFont(name:"DINCondensedC", size: 15)
//            label.font = UIFont.systemFont(ofSize: 12)
            label.textColor = UIColor.white
            label.text = day[index]
            label.textAlignment = .center
            label.frame = CGRect(x: CGFloat(index) * labelW,
                                 y:7,
                                 width:labelW,
                                 height:footerViewHeight - 13)
            footerView.addSubview(label)
        }
        footerView.frame = CGRect(x:0,
                                  y:0,
                                  width:self.view.bounds.width,
                                  height:footerViewHeight)
        return footerView
    }
    
    func creatHeaderView () {
        headerView = UIView()
        let btnWidth:CGFloat = 30.0
        
        for (index, item) in ["D","W","M"].enumerated() {
            let btn = UIButton()
            btn.frame = CGRect(x: 15 + (btnWidth + 10) * CGFloat(index),
                               y: 10,
                               width: btnWidth,
                               height:btnWidth)
            btn.setTitle(item, for: .normal)
            btn.layer.cornerRadius = btnWidth / 2.0
            btn.titleLabel?.font = UIFont.systemFont(ofSize: 13)
            btn.layer.masksToBounds = true
            btn.tag = index
            btn.addTarget(self, action: #selector(clickBtn(_:)), for: .touchUpInside)
            headerView.addSubview(btn)
        }
        turnBtnState()
        headerView.frame = CGRect(x:0,
                                  y:0,
                                  width:self.view.bounds.width,
                                  height:40)
    }
    
    func creatTipView () {
        tipLabel = UILabel()
        tipLabel.textAlignment = .center
        tipLabel.alpha = 0.0
        tipLabel.textColor = Color().color(hex: 0xEAF303)
        tipLabel.font = UIFont.systemFont(ofSize: 13)
        lineChartView.addSubview(tipLabel)
    }
    
    func showTipLabel(_ point:CGPoint,text: String) {
        let labelW = self.view.bounds.width / 7.0
        self.tipLabel.text = "\(text)%"
        self.tipLabel.frame = CGRect(x: point.x - labelW * 0.5,
                                     y: 45.0,
                                     width: labelW,
                                     height: 25
        )
        UIView.animate(withDuration: 0.1) {
            self.tipLabel.alpha = 1.0
        }
    }
    func hiddenTipLabel() {
        UIView.animate(withDuration: 0.1) {
            self.tipLabel.alpha = 0.0
        }
    }
    
    func clickBtn(_ btn:UIButton) {
        turnBtnState(btn.tag)
    }
    
    func turnBtnState(_ selectIndex: Int = 0) {
        for (index, item) in self.headerView.subviews.enumerated() {
            let btn = item as! UIButton
            if index == selectIndex {
                btn.setTitleColor(UIColor.black, for: .normal)
                btn.backgroundColor = UIColor.white
            }else {
                btn.setTitleColor(UIColor.white, for: .normal)
                btn.backgroundColor = UIColor.clear
            }
        }
    }
    
    //MARK: - JBChartViewDataSource
    
    func shouldExtendSelectionViewIntoFooterPadding(for chartView: JBChartView!) -> Bool {
        return false
    }
    
    func shouldExtendSelectionViewIntoHeaderPadding(for chartView: JBChartView!) -> Bool {
        return true
    }
    
    //MARK: - JBLineChartViewDataSource
    
    func numberOfLines(in lineChartView: JBLineChartView!) -> UInt {
        return UInt(lineValue.count)
    }
    
    func lineChartView(_ lineChartView: JBLineChartView!, numberOfVerticalValuesAtLineIndex lineIndex: UInt) -> UInt {
        return UInt(lineValue.first!.count)
    }
    
    func lineChartView(_ lineChartView: JBLineChartView!, smoothLineAtLineIndex lineIndex: UInt) -> Bool {
        return true
    }
    
    func lineChartView(_ lineChartView: JBLineChartView!, dimmedSelectionOpacityAtLineIndex lineIndex: UInt) -> CGFloat {
        if lineIndex == 0 {
            return 1.0
        }else {
            return 0.8
        }
    }
    
    //MARK: - JBLineChartViewDelegate
    
    func lineChartView(_ lineChartView: JBLineChartView!, verticalValueForHorizontalIndex horizontalIndex: UInt, atLineIndex lineIndex: UInt) -> CGFloat {
        return lineValue[Int(lineIndex)][Int(horizontalIndex)]
    }
    
    func lineChartView(_ lineChartView: JBLineChartView!, didSelectLineAt lineIndex: UInt, horizontalIndex: UInt, touch touchPoint: CGPoint) {
        let value = lineValue[0][Int(horizontalIndex)]
        showTipLabel(touchPoint, text:"\(value*100)")
    }
    
    func didDeselectLine(in lineChartView: JBLineChartView!) {
        hiddenTipLabel()
    }
    
    func lineChartView(_ lineChartView: JBLineChartView!, verticalSelectionColorForLineAtLineIndex lineIndex: UInt) -> UIColor! {
        return UIColor(white: 1.0, alpha: 0.2)
    }
    
    func verticalSelectionWidth(for lineChartView: JBLineChartView!) -> CGFloat {
        return self.view.bounds.width / 7.0
    }
    
    func lineChartView(_ lineChartView: JBLineChartView!, selectionColorForLineAtLineIndex lineIndex: UInt) -> UIColor! {
        if lineIndex == 0 {
            return UIColor.red // UIColor(white: 1.0, alpha: 0.8)
        }else {
            return nil
        }
    }
    
    func lineChartView(_ lineChartView: JBLineChartView!, fillGradientForLineAtLineIndex lineIndex: UInt) -> CAGradientLayer! {
        let gradient = CAGradientLayer()
        gradient.startPoint = CGPoint(x: 0.0, y: 0.0)
        gradient.endPoint = CGPoint(x: 1.0, y: 0.0)
        if lineIndex == 0 {
            gradient.colors = [Color().color(hex: 0x00A2E4, alpha: 0.3).cgColor, Color().color(hex: 0xEAF303, alpha: 0.3).cgColor]
            return gradient

        }else {
            gradient.colors = [UIColor(white: 1.0, alpha: 0.3).cgColor, UIColor(white: 1.0, alpha: 0.3).cgColor]
            return gradient
        }
    }
    
    func lineChartView(_ lineChartView: JBLineChartView!, gradientForLineAtLineIndex lineIndex: UInt) -> CAGradientLayer! {
        let gradient = CAGradientLayer()
        gradient.startPoint = CGPoint(x: 0.0, y: 0.0)
        gradient.endPoint = CGPoint(x: 1.0, y: 0.0)
        if lineIndex == 0 {
            gradient.colors = [Color().color(hex: 0x00A2E4).cgColor, Color().color(hex: 0xEAF303).cgColor]
            return gradient
        }else {
            return gradient
        }
    }
    
    func lineChartView(_ lineChartView: JBLineChartView!, colorStyleForLineAtLineIndex lineIndex: UInt) -> JBLineChartViewColorStyle {
        return .gradient
    }
    
    func lineChartView(_ lineChartView: JBLineChartView!, fillColorStyleForLineAtLineIndex lineIndex: UInt) -> JBLineChartViewColorStyle {
        return .gradient
    }
}

