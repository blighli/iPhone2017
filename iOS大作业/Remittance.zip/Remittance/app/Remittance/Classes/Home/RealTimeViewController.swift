//
//  RealTimeViewController.swift
//  Remittance
//
//  Created by wansy on 2017/9/20.
//  Copyright © 2017年 wansy. All rights reserved.
//

import UIKit

class RealTimeViewController: BaseViewController,UITableViewDelegate,UITableViewDataSource {

    @IBOutlet weak var imageView: MapImageView!
    @IBOutlet weak var headerView: UIView!
    @IBOutlet weak var tableView: UITableView!
    
    var remitInfoView: RemitInfoView?
    var pushController:((_ bill:OrderEntity)->())!
    
    var billArray:[OrderEntity] = []{
        didSet {
            guard tableView != nil else {
                return
            }
            tableView.reloadData()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setupTableView()
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        imageView.startAnimation()
        tableView.reloadData()
    }

    override func viewDidDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        imageView.removeLayer()
    }
    
    private func setupTableView () {
        
        tableView.register(UINib(nibName: "BillTableViewCell", bundle: nil) , forCellReuseIdentifier: BillTableViewCell.cellId)
        tableView.rowHeight = 130
        
    }

    // MARK: - UITableViewDelegate,UITableViewDataSource
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.billArray.count;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = BillTableViewCell.cellInTableView(tableView: tableView)
        cell.data = self.billArray[(self.billArray.count - 1) - indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        pushController(self.billArray[(self.billArray.count - 1) - indexPath.row])
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        if remitInfoView != nil  {
            return remitInfoView
        }
        remitInfoView = RemitInfoView.remitInfoView()
        remitInfoView!.frame = CGRect(x:0,y:0,width:self.view.bounds.width,height: 90)
        return remitInfoView
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 90;
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let offset = scrollView.contentOffset.y
        remitInfoView!.bgView.isHidden = offset < 200
    }
}
