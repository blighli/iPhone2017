//
//  HomeViewController.swift
//  Remittance
//
//  Created by wansy on 2017/9/20.
//  Copyright © 2017年 wansy. All rights reserved.
//

import UIKit

class HomeViewController: BaseViewController {

    @IBOutlet weak var segmentHeaderView: AlaoSegmentHeader!
    @IBOutlet weak var segmentView: AlaoSegmentView!
    
    var barImageView: UIImageView?
    var billArray:[OrderEntity] = []
    
    var dealViewController: DealViewController!
    var realTimelViewController: RealTimeViewController!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setup()
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationController?.navigationBar.shadowImage = UIImage()
        self.navigationController?.navigationBar.tintColor = UIColor.white
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setupTableView()
    }
    
    fileprivate func setupTableView () {
        self.showHUDWithTitle(tips: "loading...")
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.3) {
            self.hideHUD()
        }
        
        let billArr = ArchiveData.archiveData.allOrder
        self.realTimelViewController.billArray = billArr
        self.dealViewController.billArray = billArr
        
        AlaoNetwork.network.getBillList { (res) in
            guard res != nil else {
                return
            }
            ArchiveData.archiveData.allOrder = res!
            self.realTimelViewController.billArray = res!
            self.dealViewController.billArray = res!
        }
    }
    
    fileprivate func setup() {
        let billDetailVC = self.viewControllerInStoryboard(storyboardName: "Main", vcIdentifier: "BillDetailVC") as! BillDetailViewController
        
        // segamentView 中第一个子控制器
        dealViewController = self.viewControllerInStoryboard(storyboardName: "Main",
                                                                 vcIdentifier: "DealVC") as!
                                                                    DealViewController
        dealViewController.title = "Transaction"
        dealViewController.pushController = { (bill) in
            billDetailVC.orderDetail = bill
            self.navigationController!.pushViewController(billDetailVC, animated: true)
        }
        
        // segamentView 中第二个子控制器
        realTimelViewController = self.viewControllerInStoryboard(storyboardName: "Main",
                                                                        vcIdentifier: "RealTimeVC") as! RealTimeViewController
        realTimelViewController.title = "Real-Time"
        realTimelViewController.pushController = { (bill) in
            billDetailVC.orderDetail = bill
            self.navigationController!.pushViewController(billDetailVC, animated: true)
        }
        
        let vcArray = [dealViewController, realTimelViewController] as [Any]
        segmentView.subViewControllers = vcArray as! [UIViewController]
        
        segmentHeaderView.selectedTitleColor = UIColor.white
        segmentHeaderView.normalTitleColor = Color().color(hex: 0xFFFFFF, alpha: 0.5)
        segmentHeaderView.bottomColor = Color().color(hex: 0xF042DB)
        segmentView.headView = segmentHeaderView
    }
}
