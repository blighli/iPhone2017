//
//  BaseTabBarController.swift
//  Remittance
//
//  Created by wansy on 2017/9/21.
//  Copyright © 2017年 wansy. All rights reserved.
//

import UIKit

class BaseTabBarController: UITabBarController {

    @IBOutlet weak var customTabBar: CustomTabBar!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    // MARK: - UITabBarDelegate
    
    override func tabBar(_ tabBar: UITabBar, didSelect item: UITabBarItem) {
        
        for (index, bgView) in customTabBar.bgViews.enumerated() {
            
            if index == tabBar.items?.index(of: tabBar.selectedItem!) {
                bgView.backgroundColor = Color().color(hex: 0x2d3851)
            }else {
                bgView.backgroundColor = Color().color(hex: 0x56677e)
            }
            
        }
    }
}
