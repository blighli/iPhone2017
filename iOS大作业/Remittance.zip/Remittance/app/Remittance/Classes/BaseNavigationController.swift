//
//  BaseNavigationController.swift
//  Remittance
//
//  Created by wansy on 2017/9/22.
//  Copyright © 2017年 wansy. All rights reserved.
//

import UIKit

class BaseNavigationController: UINavigationController {

    var navBackgroundImage:UIImage?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let navigationBar = self.navigationBar
        navigationBar.tintColor = UIColor.white
    }
}
