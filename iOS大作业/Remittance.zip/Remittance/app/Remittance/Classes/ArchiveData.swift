//
//  ArchiveData.swift
//  Remittance
//
//  Created by wansy on 2017/11/20.
//  Copyright © 2017年 wansy. All rights reserved.
//

import Foundation

private let orderEntityKey = "orderEntityKey"
private let billNumKey = "billNumKey"
private let transactionInfoKey = "transactionInfoKey"

class ArchiveData {
    lazy var userDefault = UserDefaults.standard
    
    // 单例
    static let archiveData = ArchiveData()
    
    var allOrder:[OrderEntity] {
        get{
            var orders:[OrderEntity] = []
            let dataArr = userDefault.array(forKey: orderEntityKey)
            if dataArr != nil {
                for order in dataArr! {
                    orders.append(NSKeyedUnarchiver.unarchiveObject(with: order as! Data) as! OrderEntity)
                }
            }
            
           return orders
        }
        set{
            let orders:[OrderEntity] = newValue
            
            var dataArr:[Data] = []
            let billNumData:BillNum = BillNum.init()
            
            for order in orders{
                let data = NSKeyedArchiver.archivedData(withRootObject: order)
                dataArr.append(data)
                
                if order.clearingTime != "" {
                    billNumData.cleared = billNumData.cleared! + 1
                }else if order.recordedTime != "" {
                    billNumData.ToClearingNum = billNumData.ToClearingNum! + 1
                }else if order.changeOverTime != "" {
                    billNumData.toImportNum = billNumData.toImportNum! + 1
                }else {
                    billNumData.toChangeoverNum = billNumData.toChangeoverNum! + 1
                }
            }
            self.billNum = billNumData
            
            userDefault.removeObject(forKey: orderEntityKey)
            userDefault.set(dataArr, forKey: orderEntityKey)
            userDefault.synchronize()
        }
    }
    
    var billNum:BillNum {
        get{
            let defaultData:BillNum = BillNum.init()
            if let res = (userDefault.object(forKey: billNumKey)) as? Data {
                return NSKeyedUnarchiver.unarchiveObject(with: res) as! BillNum
            }else {
                return defaultData
            }
        }
        set{
            userDefault.removeObject(forKey: billNumKey)
            userDefault.set(NSKeyedArchiver.archivedData(withRootObject: newValue), forKey: billNumKey)
            userDefault.synchronize()
        }
    }
    
    var transactionInfo:TransactionInfo {
        get{
            if let res = userDefault.object(forKey: transactionInfoKey) as? Data {
                return NSKeyedUnarchiver.unarchiveObject(with: res) as! TransactionInfo
            }else {
                return TransactionInfo.init()
            }
        }
        set{
            userDefault.removeObject(forKey: transactionInfoKey)
            userDefault.set(NSKeyedArchiver.archivedData(withRootObject: newValue), forKey: transactionInfoKey)
            userDefault.synchronize()
        }
    }
}
