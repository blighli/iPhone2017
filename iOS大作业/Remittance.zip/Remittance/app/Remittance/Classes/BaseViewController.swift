//
//  BaseViewController.swift
//  wuliangye
//
//  Created by wansy on 16/5/9.
//  Copyright © 2016年 wansy. All rights reserved.
//

import UIKit



class BaseViewController: UIViewController,AlaoModelCallbackDelegate {
    var txhash: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.addBackButton()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        NotificationCenter.default.addObserver(self, selector: #selector(BaseViewController.didReceivedNotification(notification:)), name: NSNotification.Name(rawValue: AlaoNetworkConstants.errorNotification), object: nil)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    }
    
    deinit{
        NotificationCenter.default.removeObserver(self)
    }
    
    func didReceivedNotification(notification:NSNotification) {
//         self.hideHUD()
        if notification.name.rawValue == AlaoNetworkConstants.errorNotification {
            
            if notification.object == nil {
                self.showErrorTips(tips: "Request Failed")
            }else {
//                self.showErrorTips(tips: notification.object as! String)
//                txhash = notification.object as! String
            }
        }
    }
    
    //MARK: - private method
    
    func pop(){
        if self is BillDetailViewController {
            self.navigationController?.popToRootViewController(animated: true)
        }else {
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    /// 添加自定义返回按钮
    private func addBackButton(){
        if self.navigationController != nil && self.navigationController!.viewControllers.count > 1{
            
            self.navigationItem.leftBarButtonItem = UIBarButtonItem.barButtonItem(withImage: UIImage(named:"back")!,
                                                                                  highlightedImage: UIImage(named:"back")!,
                                                                                  target:self,
                                                                                  action:#selector(BaseViewController.pop),
                                                                                  size:CGSize(width:40,height:60)
            
            )
        }

    }
}
