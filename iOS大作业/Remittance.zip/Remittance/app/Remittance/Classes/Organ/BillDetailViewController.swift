//
//  BillDetailViewController.swift
//  Remittance
//
//  Created by wansy on 2017/9/24.
//  Copyright © 2017年 wansy. All rights reserved.
//

import UIKit

let viewHeight1:CGFloat = 104
let viewHeight2:CGFloat = 226

class BillDetailViewController: BaseViewController {
    
    @IBOutlet weak var transferView: UIView!
    @IBOutlet weak var tranferViewHeightConstraint: NSLayoutConstraint!
    
    @IBOutlet weak var importView: UIView!
    @IBOutlet weak var importViewheightConstraint: NSLayoutConstraint!
    
    @IBOutlet weak var clearingView: UIView!
    @IBOutlet weak var clearingViewHeightConstraint: NSLayoutConstraint!
    
    @IBOutlet weak var processImageView: UIImageView!
    @IBOutlet weak var handleView: UIView!
    @IBOutlet weak var handleBtn: UIButton!
    @IBOutlet weak var handleViewHeightConstraint: NSLayoutConstraint!
    
    @IBOutlet weak var IDLabel: UILabel!
    @IBOutlet weak var remitterLabel: UILabel!
    
    @IBOutlet weak var countryLabel: UILabel!
    @IBOutlet weak var agencyLabel: UILabel!
    @IBOutlet weak var addressLabel: UILabel!
    @IBOutlet weak var contactLabel: UILabel!
    @IBOutlet weak var postscriptLabel: UILabel!
    @IBOutlet weak var remitTimeLabel: UILabel!
    
    @IBOutlet weak var tranferTimeLabel: UILabel!
    
    @IBOutlet weak var balanceLabel: UILabel!
    @IBOutlet weak var payeeLabel: UILabel!
    @IBOutlet weak var inTimeLabel: UILabel!
    @IBOutlet weak var serialNumberLabel: UILabel!
    @IBOutlet weak var currencyLabel: UILabel!
    
    @IBOutlet weak var clearingTimeLabel: UILabel!
    
    var orderDetail: OrderEntity?
    var orderID: String?
    var isHandle:Bool?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // 不是从机构进入的详情页 都不允许操作
        if isHandle != true {
            self.handleView.isHidden = true
            self.handleViewHeightConstraint.constant = 0
        }

//        if orderID != nil {
//            self.getOrderDetail(orderId: orderID!)
//        }
    }
    
    func getOrderDetail (orderId: String) {
        self.showHUDWithTitle(tips: "loading...")
        AlaoNetwork.network.getOrder(ID: orderId, completionHandler: { (res) in
            self.orderDetail = res
            self.setDetail()
        })
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setDetail()
    }
    
    func setDetail () {
        var btnTitle = ""
        let type = RemittanceType.getState(orderDetail)
        switch type {
        case .remited:
            
            btnTitle = "Transfer"
        case .changOvered:
            transferView.isHidden = false
            tranferViewHeightConstraint.constant = viewHeight1
            
            self.handleView.isHidden = true
            self.handleViewHeightConstraint.constant = 0
        case .imported:
            transferView.isHidden = false
            tranferViewHeightConstraint.constant = viewHeight1
            importView.isHidden = false
            importViewheightConstraint.constant = viewHeight2
            
            btnTitle = "Liquidate"
        case .cleared:
            self.handleView.isHidden = true
            self.handleViewHeightConstraint.constant = 0
            
            transferView.isHidden = false
            tranferViewHeightConstraint.constant = viewHeight1
            importView.isHidden = false
            importViewheightConstraint.constant = viewHeight2
            clearingView.isHidden = false
            clearingViewHeightConstraint.constant = viewHeight1
        }
        self.handleBtn.setTitle(btnTitle, for: .normal)
        self.processImageView.image = UIImage(named: type.imageName())
        
        IDLabel.text = orderDetail?.orderID
        remitterLabel.text = orderDetail?.remitterName
        countryLabel.text = orderDetail?.remitterCountry
        agencyLabel.text = orderDetail?.remitAgency
        addressLabel.text = orderDetail?.remitterAddress
        contactLabel.text = orderDetail?.remitterContact
        postscriptLabel.text = orderDetail?.remitPostscript
        remitTimeLabel.text = timeFilter(timeInterval: orderDetail?.startRemitTime ?? "")
        
        tranferTimeLabel.text = timeFilter(timeInterval: orderDetail?.changeOverTime ?? "")
        
        balanceLabel.text = orderDetail?.amount
        payeeLabel.text = orderDetail?.payeeName
        inTimeLabel.text = timeFilter(timeInterval: orderDetail?.recordedTime ?? "")
        serialNumberLabel.text = orderDetail?.serialNumber
        currencyLabel.text = orderDetail?.currency
        inTimeLabel.text = timeFilter(timeInterval: orderDetail?.recordedTime ?? "")
        clearingTimeLabel.text = timeFilter(timeInterval: orderDetail?.clearingTime ?? "")
    }
    
    @IBAction func clickBtn(_ sender: UIButton) {
        switch RemittanceType.getState(orderDetail) {
        case .remited:
            transfer()
        case .changOvered:
            return
        case .imported:
            liquidate()
        case .cleared:
            break
        }
    }
    
    func transfer() {
        self.showHUDWithTitle(tips: "loading...")
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.6) {
            self.showSuccessTips(tips: "Transfer Success!")
            
            self.handleView.isHidden = true
            self.handleViewHeightConstraint.constant = 0
            self.orderDetail?.changeOverTime = Util.getNowTimeInterval()
            self.setDetail()
        }
        
        AlaoNetwork.network.changeover(cardNo: (orderDetail?.orderID)!) { result in
            AlaoNetwork.network.getBillList { (res) in
                guard res != nil else {
                    return
                }
                ArchiveData.archiveData.allOrder = res!
            }
        }
    }
    
    func liquidate() {
        self.showHUDWithTitle(tips: "loading...")
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.6) {
           self.showSuccessTips(tips: "Liquidate Success!")
            
            self.handleView.isHidden = true
            self.handleViewHeightConstraint.constant = 0
            self.orderDetail?.clearingTime = Util.getNowTimeInterval()
            self.setDetail()
        }
        AlaoNetwork.network.clearing(ID: (orderDetail?.orderID)!,fileID: (orderDetail?.orderID)!) { result in
            AlaoNetwork.network.getBillList { (res) in
                guard res != nil else {
                    return
                }
                ArchiveData.archiveData.allOrder = res!
            }
        }
    }
    
    func timeFilter(timeInterval: String) -> String{
        guard timeInterval != "0" && Double(timeInterval) != nil else {
            return "untreated"
        }
        return Util.getDateStr(withTimeInterval: Double(timeInterval)!)
    }
    
}
