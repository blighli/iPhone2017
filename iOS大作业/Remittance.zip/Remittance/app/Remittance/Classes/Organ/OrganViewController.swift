//
//  OrganViewController.swift
//  Remittance
//
//  Created by wansy on 2017/9/22.
//  Copyright © 2017年 wansy. All rights reserved.
//

import UIKit

class OrganViewController: BaseViewController {

    var organType:OrganType?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationController?.navigationBar.shadowImage = UIImage()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.destination is BillListViewController {
            let vc = segue.destination as! BillListViewController
            vc.organType = organType;
        }
    }
    
    //MARK: - Event Response
    
    @IBAction func clickOrganBtn(_ sender: UIButton) {
        organType = OrganType.fromRawValue(raw: sender.tag)
    }
}
