//
//  BillListViewController.swift
//  Remittance
//
//  Created by wansy on 2017/9/24.
//  Copyright © 2017年 wansy. All rights reserved.
//

import UIKit

class BillListViewController: BaseViewController, UITableViewDataSource,UITableViewDelegate{

    @IBOutlet weak var organImageView: UIImageView!
    @IBOutlet weak var organName: UILabel!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var headerView: UIView!
    @IBOutlet weak var remitBtn: UIButton!
    
    @IBOutlet weak var totalNumLabel: UILabel!
    @IBOutlet weak var totalNumNameLabel: UILabel!
    
    @IBOutlet weak var firstNumLabel: UILabel!
    @IBOutlet weak var firstNumNameLabel: UILabel!
    
    @IBOutlet weak var secondNumLabel: UILabel!
    @IBOutlet weak var secondNumNameLabel: UILabel!
    
    var organType: OrganType?
    var billArray:[OrderEntity] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.setupTableView()
        
        self.setupOrganDiff()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.getBillList()
    }
    
    // MARK: - private method
    
    private func setupTableView () {
        tableView.register(UINib(nibName: "BillTableViewCell", bundle: nil) , forCellReuseIdentifier: BillTableViewCell.cellId)
        tableView.rowHeight = 130
        
        remitBtn.layer.borderColor = UIColor.white.cgColor
        remitBtn.layer.borderWidth = 1
        remitBtn.layer.cornerRadius = 4
        remitBtn.layer.masksToBounds = true
    }
    
    private func getBillList() {
        self.showHUDWithTitle(tips: "loading...")
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.3) {
            self.hideHUD()
            let billArr = ArchiveData.archiveData.allOrder
            self.setupTableView(data: billArr)
            let billNum = ArchiveData.archiveData.billNum
            self.setupBillNum(billNum: billNum)
        }
        
        AlaoNetwork.network.getBillList { (res) in
            guard res != nil else {
                return
            }
            
            ArchiveData.archiveData.allOrder = res!
            self.setupTableView(data: res!)
            self.setupBillNum(billNum: ArchiveData.archiveData.billNum)
        }
    }
    
    private func setupTableView(data:[OrderEntity]) {
        var remittanceType:RemittanceType = .remited
        switch self.organType! {
        case .remit:
            remittanceType = .cleared
        case .changeOver:
            remittanceType = .remited
        case .import:
            remittanceType = .changOvered
        case .clearing:
            remittanceType = .imported
        }
        
        var list:[OrderEntity] = []
        for order in data {
            if (RemittanceType.getState(order) == remittanceType || RemittanceType.getState(order) == .cleared) {
                list.append(order)
            }
        }
        
        self.billArray = list
        self.tableView.reloadData()
    }
    
    private func setupBillNum(billNum:BillNum) {
        self.totalNumLabel.text = "\(billNum.cleared! + billNum.toChangeoverNum! + billNum.toImportNum! + billNum.ToClearingNum!)"
        self.secondNumLabel.text = "\(String(describing: billNum.cleared!))"
        self.secondNumNameLabel.text = "Liquidated"
        switch self.organType! {
        case .remit:
            self.firstNumLabel.text = "0"
            self.firstNumNameLabel.text = "To Remit"
        case .changeOver:
            self.firstNumLabel.text = "\(String(describing: billNum.toChangeoverNum!))"
            self.firstNumNameLabel.text = "To Transfer"
        case .import:
            self.firstNumLabel.text = "\(String(describing: billNum.toImportNum!))"
            self.firstNumNameLabel.text = "To Recorded"
        case .clearing:
            self.firstNumLabel.text = "\(String(describing: billNum.ToClearingNum!))"
            self.firstNumNameLabel.text = "To Liquidate"
        }

    }
    
    private func setupOrganDiff () {
        if organType != .remit {
            self.tableView.tableHeaderView = nil
        }
        
        organImageView.image = UIImage(named: (organType?.organImageName())!)
        organName.text = (organType?.organDetailName())!
        self.title = (organType?.organName())!
    }
    
    // MARK: - UITableViewDataSource,UITableViewDelegate
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.billArray.count;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = BillTableViewCell.cellInTableView(tableView: tableView)
        cell.data = self.billArray[(self.billArray.count - 1) - indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let data:OrderEntity = self.billArray[(self.billArray.count - 1) - indexPath.row]
        
        if RemittanceType.getState(data) == .changOvered {
            let recordedVC = self.viewControllerInStoryboard(storyboardName: "Main", vcIdentifier: "RecordedVC") as! RecordedViewController
            recordedVC.orderDetail = self.billArray[(self.billArray.count - 1) - indexPath.row]
            self.navigationController!.pushViewController(recordedVC, animated: true)
        }else {
            let billDetailVC = self.viewControllerInStoryboard(storyboardName: "Main", vcIdentifier: "BillDetailVC") as! BillDetailViewController
            billDetailVC.isHandle = true
            billDetailVC.orderDetail = self.billArray[(self.billArray.count - 1) - indexPath.row]
            self.navigationController!.pushViewController(billDetailVC, animated: true)
        }
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        if self.billArray.count != 0 {
            return nil
        }else {
            let noRecordView = NoRecordView.noRecordView()
            return noRecordView
        }
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if self.billArray.count == 0 {
            return 260
        }else {
            return 0
        }
    }
}
