//
//  AddBillViewController.swift
//  Remittance
//
//  Created by wansy on 2017/9/25.
//  Copyright © 2017年 wansy. All rights reserved.
//

import UIKit

class AddBillViewController: BaseViewController {

    @IBOutlet weak var remittcanceIDTextField: AlaoTextField!
    
    @IBOutlet weak var remitterTextField: AlaoTextField!
    @IBOutlet weak var countryTextField: AlaoTextField!
    @IBOutlet weak var institutionTextField: AlaoTextField!
    
    @IBOutlet weak var addressTextField: AlaoTextField!
    @IBOutlet weak var contactTextField: AlaoTextField!
    @IBOutlet weak var postscriptTextField: AlaoTextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "Recorded"
    }
    
    @IBAction func clickBtn(_ sender: UIButton) {
        guard self.remittcanceIDTextField.text != "",
            self.remitterTextField.text != "",
            self.countryTextField.text != "",
            self.institutionTextField.text != "",
            self.addressTextField.text != "",
            self.contactTextField.text != "",
            self.postscriptTextField.text != ""
            else {
                self.showTips(tips: "Please fill your information")
                return
        }
        
        var dicParams:Dictionary<String, Any> = [:]
        dicParams["ID"]              = self.remittcanceIDTextField.text
        dicParams["remitterName"]    = self.remitterTextField.text
        dicParams["remitterCountry"] = self.countryTextField.text
        dicParams["remitAgency"]     = self.institutionTextField.text
        dicParams["remitterAddress"] = self.addressTextField.text
        dicParams["remitterContact"] = self.contactTextField.text
        dicParams["remitPostscript"] = self.postscriptTextField.text
        
        
        self.showHUDWithTitle(tips: "loading...")
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.3) {
            self.hideHUD()
            
            let orderDetail:OrderEntity = OrderEntity.init()
            orderDetail.orderID = self.remittcanceIDTextField.text ?? ""
            orderDetail.remitterName = self.remitterTextField.text ?? ""
            orderDetail.remitterCountry = self.countryTextField.text ?? ""
            orderDetail.remitAgency = self.institutionTextField.text ?? ""
            orderDetail.remitterAddress = self.addressTextField.text ?? ""
            orderDetail.remitterContact = self.contactTextField.text ?? ""
            orderDetail.remitPostscript = self.postscriptTextField.text ?? ""
            orderDetail.startRemitTime = Util.getNowTimeInterval()
            
            let billDetailVC = self.viewControllerInStoryboard(storyboardName: "Main", vcIdentifier: "BillDetailVC") as! BillDetailViewController
            billDetailVC.orderDetail = orderDetail
            self.navigationController?.pushViewController(billDetailVC, animated: true)
        }
        
        AlaoNetwork.network.startRemitMoney(params: dicParams as [String : AnyObject]) { (result:OrderEntity?) in
            AlaoNetwork.network.getBillList { (res) in
                guard res != nil else {
                    return
                }
                ArchiveData.archiveData.allOrder = res!
            }
        }
    }
}
