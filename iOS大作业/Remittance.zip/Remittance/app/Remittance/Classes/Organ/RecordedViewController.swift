
//
//  RecordedViewController.swift
//  Remittance
//
//  Created by wansy on 2017/9/29.
//  Copyright © 2017年 wansy. All rights reserved.
//

import UIKit

class RecordedViewController: BaseViewController {
    
    @IBOutlet weak var payeeTextField: AlaoTextField!
    @IBOutlet weak var SerialNumberTextField: AlaoTextField!
    @IBOutlet weak var CurrencyTextField: AlaoTextField!
    
    @IBOutlet weak var balanceTextField: AlaoTextField!
    
    var orderDetail: OrderEntity?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func recorded(_ sender: UIButton) {
        guard self.payeeTextField.text != "",
            self.SerialNumberTextField.text != "",
            self.CurrencyTextField.text != "",
            self.balanceTextField.text != ""
            else {
                self.showTips(tips: "Please fill your information")
                return
        }
        
        var dicParams:Dictionary<String, Any> = [:]
        dicParams["ID"]           = self.orderDetail!.orderID
        dicParams["payeeName"]    = self.payeeTextField.text
        dicParams["serialNumber"] = self.SerialNumberTextField.text
        dicParams["currency"]     = self.CurrencyTextField.text
        dicParams["amount"]       = self.balanceTextField.text
        
        self.showHUDWithTitle(tips: "loading...")
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.3) {
            self.hideHUD()
            self.orderDetail!.payeeName = self.payeeTextField.text ?? ""
            self.orderDetail!.serialNumber = self.SerialNumberTextField.text ?? ""
            self.orderDetail!.currency = self.CurrencyTextField.text ?? ""
            self.orderDetail!.amount = self.balanceTextField.text ?? ""
            self.orderDetail!.recordedTime = Util.getNowTimeInterval()
            
            let billDetailVC = self.viewControllerInStoryboard(storyboardName: "Main", vcIdentifier: "BillDetailVC") as! BillDetailViewController
            billDetailVC.orderDetail = self.orderDetail!
            self.navigationController?.pushViewController(billDetailVC, animated: true)
        }
        
        AlaoNetwork.network.recorded(params: dicParams as [String : AnyObject]) { (res) in
          //  guard res != nil else {return}
            AlaoNetwork.network.getBillList { (res) in
                guard res != nil else {
                    return
                }
                ArchiveData.archiveData.allOrder = res!
            }
        }
        
    }

}
