//
//  BillTableViewCell.swift
//  Remittance
//
//  Created by wansy on 2017/9/22.
//  Copyright © 2017年 wansy. All rights reserved.
//

import UIKit

class BillTableViewCell: UITableViewCell {

    @IBOutlet weak var ID: UILabel!
    @IBOutlet weak var state: UILabel!
    
    
    static var cellId:String{
        return "BillCellID"
    }
    
    var data:OrderEntity? {
        willSet {
            ID.text = newValue?.orderID
            state.text = getState(newValue)
        }
    }
    
    private func getState (_ order:OrderEntity?) -> String{
        guard let order = order else {
            return ""
        }
        
        if order.clearingTime != "" {
            return "Liquidated"
        }else if order.recordedTime != "" {
            return "To Liquidate"
        }else if order.changeOverTime != "" {
            return "To Recorded"
        }else if order.startRemitTime != "" {
            return "To Transfer"
        }else {
            return ""
        }
    }
    
    class func cellInTableView(tableView: UITableView) -> BillTableViewCell {
        
        var cell = tableView.dequeueReusableCell(withIdentifier: cellId) as? BillTableViewCell
        
        if cell == nil {
            cell = BillTableViewCell(style: UITableViewCellStyle.default, reuseIdentifier: cellId)
        }
        return cell!
    }
    
}
