#InfiniteHelp

###项目主题
搭建一个线上接单服务平台,服务商在线上发布服务,有需求的用户可以选择服务商来完成他的需求

###使用技术
1. Objective-c开发语言
2. cocopods管理第三方库
3. xib + autolayout快速搭建
4. MVC的开发模式 分离控制器 视图 数据

###使用第三方库
1. AFNetworking网络请求
2. IQKeyboardManager管理键盘弹出
3. MJRefresh列表下拉刷新
4. SDWebImage网络图片展示

###完成进度
1. 首页瀑布流展示完成(mock接口数据)
2. 项目列表页完成
3. 消息列表页完成
4. 登录页面完成 



