//
//  ProjectTabVCell.m
//  InfiniteHelp
//
//  Created by sands on 16/7/22.
//  Copyright © 2016年 sands. All rights reserved.
//

#import "ProjectTabVCell.h"

@implementation ProjectTabVCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
