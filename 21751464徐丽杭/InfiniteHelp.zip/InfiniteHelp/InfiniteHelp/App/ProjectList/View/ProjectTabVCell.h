//
//  ProjectTabVCell.h
//  InfiniteHelp
//
//  Created by sands on 16/7/22.
//  Copyright © 2016年 sands. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ProjectTabVCell : UITableViewCell

@end
