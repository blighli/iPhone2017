//
//  UserHeadView.h
//  InfiniteHelp
//
//  Created by joker on 2017/12/1.
//  Copyright © 2017年 sands. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UserHeadView : UIView
@property (weak, nonatomic) IBOutlet UIButton *loginBtn;

@end
