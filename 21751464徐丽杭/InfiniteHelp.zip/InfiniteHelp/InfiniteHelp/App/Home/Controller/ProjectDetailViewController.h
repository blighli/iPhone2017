//
//  ProjectDetailViewController.h
//  InfiniteHelp
//
//  Created by sands on 16/7/25.
//  Copyright © 2016年 sands. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ProjectDetailViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITableView *ProjectTabel;

@end
