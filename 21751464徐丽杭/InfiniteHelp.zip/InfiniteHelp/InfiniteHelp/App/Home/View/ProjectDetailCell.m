//
//  ProjectDetailCell.m
//  InfiniteHelp
//
//  Created by sands on 16/7/26.
//  Copyright © 2016年 sands. All rights reserved.
//

#import "ProjectDetailCell.h"

@implementation ProjectDetailCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
