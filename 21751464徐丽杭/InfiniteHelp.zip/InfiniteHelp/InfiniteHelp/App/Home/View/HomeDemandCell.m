//
//  HomeDemandCell.m
//  InfiniteHelp
//
//  Created by sands on 16/7/21.
//  Copyright © 2016年 sands. All rights reserved.
//

#import "HomeDemandCell.h"

@implementation HomeDemandCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
