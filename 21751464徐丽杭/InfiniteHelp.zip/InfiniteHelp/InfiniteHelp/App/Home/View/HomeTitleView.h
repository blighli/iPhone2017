//
//  HomeTitleView.h
//  InfiniteHelp
//
//  Created by sands on 16/7/21.
//  Copyright © 2016年 sands. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeTitleView : UIView
@property (weak, nonatomic) IBOutlet UIButton *ClassifyBtn;

@end
