//
//  InfiniteHelpNav.h
//  InfiniteHelp
//
//  Created by sands on 16/7/26.
//  Copyright © 2016年 sands. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InfiniteHelpNav : UINavigationController

@end
