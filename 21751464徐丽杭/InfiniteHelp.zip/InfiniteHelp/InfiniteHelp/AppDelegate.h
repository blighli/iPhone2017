//
//  AppDelegate.h
//  InfiniteHelp
//
//  Created by sands on 16/7/18.
//  Copyright © 2016年 sands. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

